import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Alert,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Stack, useRouter, useLocalSearchParams } from "expo-router";
import {
  Shield,
  CheckCircle,
  Zap,
  File,
  Folder,
} from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { useWipeStore } from "@/store/wipe-store";

interface WipeFile {
  name: string;
  size: number;
  type: "file" | "folder";
}

export default function WipeProgressScreen() {
  const [progress, setProgress] = useState(0);
  const [currentFile, setCurrentFile] = useState<string>("");
  const [isComplete, setIsComplete] = useState(false);
  const [wipedFiles, setWipedFiles] = useState<WipeFile[]>([]);
  const [currentPhase, setCurrentPhase] = useState("Initializing...");
  
  const progressAnim = new Animated.Value(0);
  const pulseAnim = new Animated.Value(1);
  
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams();
  const { addWipeRecord } = useWipeStore();

  const files: WipeFile[] = params.files ? JSON.parse(params.files as string) : [];
  const totalSize = parseInt(params.totalSize as string) || 0;

  useEffect(() => {
    startWipeProcess();
    startPulseAnimation();
  }, []);

  const startPulseAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const startWipeProcess = async () => {
    const phases = [
      "Analyzing files...",
      "Preparing secure deletion...",
      "Pass 1: Writing zeros...",
      "Pass 2: Writing ones...",
      "Pass 3: Random overwrite...",
      "Verifying deletion...",
      "Finalizing...",
    ];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setCurrentFile(file.name);
      
      for (let phaseIndex = 0; phaseIndex < phases.length; phaseIndex++) {
        setCurrentPhase(phases[phaseIndex]);
        
        // Simulate phase progress
        for (let step = 0; step < 10; step++) {
          const fileProgress = (i / files.length) * 100;
          const phaseProgress = (phaseIndex / phases.length) * (100 / files.length);
          const stepProgress = (step / 10) * (100 / files.length / phases.length);
          const totalProgress = fileProgress + phaseProgress + stepProgress;
          
          setProgress(Math.min(totalProgress, 100));
          
          Animated.timing(progressAnim, {
            toValue: totalProgress / 100,
            duration: 100,
            useNativeDriver: false,
          }).start();
          
          await new Promise(resolve => setTimeout(resolve, 50));
        }
      }
      
      // Add to wiped files
      setWipedFiles(prev => [...prev, file]);
      
      // Add to store
      addWipeRecord({
        name: file.name,
        type: file.type,
        size: file.size,
        algorithm: "DoD 5220.22-M",
        status: "completed",
      });
    }

    // Complete the process
    setProgress(100);
    setCurrentPhase("Wipe completed successfully!");
    setIsComplete(true);
    
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }

    // Show completion alert after a delay
    setTimeout(() => {
      Alert.alert(
        "Wipe Complete",
        `Successfully wiped ${files.length} item(s). Your data is now secure.`,
        [
          {
            text: "Done",
            onPress: () => router.replace("/(tabs)"),
          },
        ]
      );
    }, 2000);
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Stack.Screen
        options={{
          headerShown: true,
          headerTitle: "Secure Wipe",
          headerStyle: { backgroundColor: "#0F172A" },
          headerTintColor: "#FFFFFF",
          headerTitleStyle: { fontWeight: "bold" },
          headerBackVisible: false,
        }}
      />

      <View style={styles.content}>
        {/* Main Progress Circle */}
        <View style={styles.progressContainer}>
          <Animated.View
            style={[
              styles.progressCircle,
              {
                transform: [{ scale: pulseAnim }],
              },
            ]}
          >
            <LinearGradient
              colors={isComplete ? ["#10B981", "#059669"] : ["#7C3AED", "#3B82F6"]}
              style={styles.progressGradient}
            >
              {isComplete ? (
                <CheckCircle color="#FFFFFF" size={48} />
              ) : (
                <Shield color="#FFFFFF" size={48} />
              )}
            </LinearGradient>
          </Animated.View>
          
          {/* Progress Ring */}
          <View style={styles.progressRing}>
            <Animated.View
              style={[
                styles.progressFill,
                {
                  transform: [
                    {
                      rotate: progressAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ["0deg", "360deg"],
                      }),
                    },
                  ],
                },
              ]}
            />
          </View>
        </View>

        {/* Progress Text */}
        <Text style={styles.progressText}>{Math.round(progress)}%</Text>
        <Text style={styles.phaseText}>{currentPhase}</Text>

        {/* Current File */}
        {currentFile && !isComplete && (
          <View style={styles.currentFileCard}>
            <LinearGradient
              colors={["#1E293B", "#334155"]}
              style={styles.currentFileGradient}
            >
              <Zap color="#F59E0B" size={20} />
              <View style={styles.currentFileInfo}>
                <Text style={styles.currentFileLabel}>Currently Wiping</Text>
                <Text style={styles.currentFileName}>{currentFile}</Text>
              </View>
            </LinearGradient>
          </View>
        )}

        {/* Statistics */}
        <View style={styles.statsCard}>
          <LinearGradient
            colors={["#7C3AED", "#3B82F6"]}
            style={styles.statsGradient}
          >
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{files.length}</Text>
                <Text style={styles.statLabel}>Items</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{formatBytes(totalSize)}</Text>
                <Text style={styles.statLabel}>Total Size</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{wipedFiles.length}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* Algorithm Info */}
        <View style={styles.algorithmCard}>
          <LinearGradient
            colors={["#1E293B", "#334155"]}
            style={styles.algorithmGradient}
          >
            <Shield color="#8B5CF6" size={20} />
            <View style={styles.algorithmInfo}>
              <Text style={styles.algorithmTitle}>DoD 5220.22-M Standard</Text>
              <Text style={styles.algorithmDescription}>
                Military-grade 3-pass overwrite for maximum security
              </Text>
            </View>
          </LinearGradient>
        </View>

        {/* Completed Files List */}
        {wipedFiles.length > 0 && (
          <View style={styles.completedSection}>
            <Text style={styles.completedTitle}>Completed Files</Text>
            {wipedFiles.slice(-3).map((file, index) => {
              const Icon = file.type === "folder" ? Folder : File;
              return (
                <View key={index} style={styles.completedItem}>
                  <LinearGradient
                    colors={["#10B981", "#059669"]}
                    style={styles.completedGradient}
                  >
                    <Icon color="#FFFFFF" size={16} />
                    <Text style={styles.completedName}>{file.name}</Text>
                    <CheckCircle color="#FFFFFF" size={16} />
                  </LinearGradient>
                </View>
              );
            })}
            {wipedFiles.length > 3 && (
              <Text style={styles.moreText}>
                +{wipedFiles.length - 3} more files completed
              </Text>
            )}
          </View>
        )}

        {/* Security Message */}
        {isComplete && (
          <View style={styles.securityMessage}>
            <LinearGradient
              colors={["#10B981", "#059669"]}
              style={styles.securityGradient}
            >
              <CheckCircle color="#FFFFFF" size={24} />
              <View style={styles.securityText}>
                <Text style={styles.securityTitle}>Your Data is Safe Now</Text>
                <Text style={styles.securityDescription}>
                  All selected files have been securely wiped and cannot be recovered.
                </Text>
              </View>
            </LinearGradient>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0F172A",
  },
  content: {
    flex: 1,
    padding: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  progressContainer: {
    position: "relative",
    marginBottom: 32,
  },
  progressCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    overflow: "hidden",
  },
  progressGradient: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  progressRing: {
    position: "absolute",
    top: -10,
    left: -10,
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 4,
    borderColor: "rgba(139, 92, 246, 0.2)",
  },
  progressFill: {
    position: "absolute",
    top: -2,
    left: -2,
    width: 4,
    height: 72,
    backgroundColor: "#8B5CF6",
    borderRadius: 2,
    transformOrigin: "2px 72px",
  },
  progressText: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  phaseText: {
    fontSize: 16,
    color: "#94A3B8",
    textAlign: "center",
    marginBottom: 32,
  },
  currentFileCard: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 24,
  },
  currentFileGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  currentFileInfo: {
    marginLeft: 12,
    flex: 1,
  },
  currentFileLabel: {
    fontSize: 12,
    color: "#94A3B8",
    marginBottom: 2,
  },
  currentFileName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  statsCard: {
    width: "100%",
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 24,
  },
  statsGradient: {
    padding: 20,
  },
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
  },
  statValue: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  statLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    marginHorizontal: 16,
  },
  algorithmCard: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 24,
  },
  algorithmGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  algorithmInfo: {
    marginLeft: 12,
    flex: 1,
  },
  algorithmTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
    marginBottom: 2,
  },
  algorithmDescription: {
    fontSize: 12,
    color: "#94A3B8",
  },
  completedSection: {
    width: "100%",
    marginBottom: 24,
  },
  completedTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 12,
  },
  completedItem: {
    borderRadius: 8,
    overflow: "hidden",
    marginBottom: 8,
  },
  completedGradient: {
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
  },
  completedName: {
    fontSize: 14,
    color: "#FFFFFF",
    marginLeft: 8,
    flex: 1,
  },
  moreText: {
    fontSize: 12,
    color: "#64748B",
    textAlign: "center",
    marginTop: 8,
  },
  securityMessage: {
    width: "100%",
    borderRadius: 16,
    overflow: "hidden",
  },
  securityGradient: {
    padding: 20,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  securityText: {
    marginLeft: 12,
    flex: 1,
  },
  securityTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 4,
  },
  securityDescription: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 20,
  },
});