import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Modal,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Shield,
  HardDrive,
  Trash2,
  FileX,
  FolderX,
  Database,
  Smartphone,
  AlertTriangle,
  X,
} from "lucide-react-native";
import { useWipeStore } from "@/store/wipe-store";
import { useRouter } from "expo-router";
import { storageService, StorageInfo } from "@/store/storage-service";
import { useTheme } from "@/store/theme-context";
import { useSettingsStore } from "@/store/settings-store";
import { useTranslations } from "@/store/translations";

export default function HomeScreen() {
  const { totalWipes, totalDataWiped } = useWipeStore();
  const { colors } = useTheme();
  const { language } = useSettingsStore();
  const t = useTranslations(language);
  const [storageInfo, setStorageInfo] = useState<StorageInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showWipeModal, setShowWipeModal] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const insets = useSafeAreaInsets();
  const router = useRouter();


  useEffect(() => {
    loadStorageInfo();
  }, []);

  const loadStorageInfo = async () => {
    try {
      setIsLoading(true);
      const info = await storageService.getStorageInfo();
      setStorageInfo(info);
    } catch (error) {
      console.log('Error loading storage info:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const handleFullDeviceWipe = () => {
    setShowWipeModal(true);
  };

  const handleProceedToConfirm = () => {
    setShowWipeModal(false);
    setShowConfirmModal(true);
  };

  const handleFinalConfirm = () => {
    setShowConfirmModal(false);
    router.push("/full-device-wipe");
  };

  const WipeWarningModal = () => (
    <Modal
      visible={showWipeModal}
      transparent
      animationType="fade"
      onRequestClose={() => setShowWipeModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
          <View style={styles.modalHeader}>
            <AlertTriangle color={colors.error} size={32} />
            <Text style={[styles.modalTitle, { color: colors.text }]}>⚠️ CRITICAL WARNING</Text>
            <TouchableOpacity onPress={() => setShowWipeModal(false)} style={styles.closeButton}>
              <X color={colors.textMuted} size={24} />
            </TouchableOpacity>
          </View>
          
          <Text style={[styles.modalText, { color: colors.text }]}>
            Full Device Wipe will permanently erase ALL data on this device including:
          </Text>
          
          <View style={styles.warningList}>
            <Text style={[styles.warningItem, { color: colors.text }]}>• All personal files and photos</Text>
            <Text style={[styles.warningItem, { color: colors.text }]}>• All apps and app data</Text>
            <Text style={[styles.warningItem, { color: colors.text }]}>• System settings and accounts</Text>
            <Text style={[styles.warningItem, { color: colors.text }]}>• Everything stored on internal storage</Text>
          </View>
          
          <Text style={[styles.modalWarning, { color: colors.error }]}>
            This action is IRREVERSIBLE and cannot be undone!
          </Text>
          
          <Text style={[styles.modalQuestion, { color: colors.text }]}>
            Are you absolutely sure you want to proceed?
          </Text>
          
          <View style={styles.modalButtons}>
            <TouchableOpacity
              onPress={() => setShowWipeModal(false)}
              style={[styles.modalButton, styles.cancelButton, { backgroundColor: colors.cardVariant }]}
            >
              <Text style={[styles.modalButtonText, { color: colors.text }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleProceedToConfirm}
              style={[styles.modalButton, styles.destructiveButton]}
            >
              <Text style={styles.destructiveButtonText}>I Understand - Proceed</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  const FinalConfirmModal = () => (
    <Modal
      visible={showConfirmModal}
      transparent
      animationType="fade"
      onRequestClose={() => setShowConfirmModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
          <View style={styles.modalHeader}>
            <AlertTriangle color="#DC2626" size={32} />
            <Text style={[styles.modalTitle, { color: colors.text }]}>🔴 FINAL CONFIRMATION</Text>
            <TouchableOpacity onPress={() => setShowConfirmModal(false)} style={styles.closeButton}>
              <X color={colors.textMuted} size={24} />
            </TouchableOpacity>
          </View>
          
          <Text style={[styles.modalText, { color: colors.text }]}>
            This is your FINAL warning!
          </Text>
          
          <Text style={[styles.modalText, { color: colors.text }]}>
            You are about to permanently destroy ALL data on this device using military-grade wiping algorithms.
          </Text>
          
          <View style={styles.modalButtons}>
            <TouchableOpacity
              onPress={() => setShowConfirmModal(false)}
              style={[styles.modalButton, styles.cancelButton, { backgroundColor: colors.cardVariant }]}
            >
              <Text style={[styles.modalButtonText, { color: colors.text }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleFinalConfirm}
              style={[styles.modalButton, styles.destructiveButton]}
            >
              <Text style={styles.destructiveButtonText}>WIPE DEVICE</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  const QuickActionCard = ({
    icon: Icon,
    title,
    subtitle,
    onPress,
    gradient,
    isDestructive = false,
  }: {
    icon: any;
    title: string;
    subtitle: string;
    onPress: () => void;
    gradient: readonly [string, string, ...string[]];
    isDestructive?: boolean;
  }) => (
    <TouchableOpacity onPress={onPress} style={styles.quickActionCard}>
      <LinearGradient colors={gradient} style={styles.quickActionGradient}>
        {isDestructive && (
          <View style={styles.warningBadge}>
            <AlertTriangle color="#FFFFFF" size={12} />
          </View>
        )}
        <Icon color="#FFFFFF" size={24} />
        <Text style={styles.quickActionTitle}>{title}</Text>
        <Text style={styles.quickActionSubtitle}>{subtitle}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <WipeWarningModal />
      <FinalConfirmModal />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <View style={styles.headerLeft}>
            <Image 
              source={{ uri: 'https://r2-pub.rork.com/generated-images/77ab697f-c5b4-4975-8283-a27fc23f07bc.png' }}
              style={styles.logo}
              resizeMode="contain"
            />
            <View style={styles.headerText}>
              <Text style={[styles.greeting, { color: colors.text }]}>WipeX</Text>
              <Text style={[styles.subtitle, { color: colors.textMuted }]}>{t.militaryGrade}</Text>
            </View>
          </View>
          <View style={styles.shieldContainer}>
            <LinearGradient
              colors={[colors.primary, colors.primaryVariant]}
              style={styles.shieldGradient}
            >
              <Shield color="#FFFFFF" size={28} />
            </LinearGradient>
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <LinearGradient
              colors={[colors.card, colors.cardVariant]}
              style={styles.statGradient}
            >
              <HardDrive color={colors.primary} size={24} />
              <TouchableOpacity onPress={() => router.push("/storage-analyzer")}>
                <Text style={[styles.statValue, { color: colors.text }]}>
                  {isLoading ? "..." : formatBytes(storageInfo?.totalSpace || 0)}
                </Text>
                <Text style={[styles.statLabel, { color: colors.textMuted }]}>{t.totalStorage}</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient
              colors={[colors.card, colors.cardVariant]}
              style={styles.statGradient}
            >
              <Database color={colors.secondary} size={24} />
              <TouchableOpacity onPress={() => router.push("/storage-analyzer")}>
                <Text style={[styles.statValue, { color: colors.text }]}>
                  {isLoading ? "..." : formatBytes(storageInfo?.freeSpace || 0)}
                </Text>
                <Text style={[styles.statLabel, { color: colors.textMuted }]}>{t.freeSpace}</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>
        </View>

        {/* Wipe Statistics */}
        <View style={styles.wipeStatsCard}>
          <LinearGradient
            colors={[colors.primary, colors.primaryVariant]}
            style={styles.wipeStatsGradient}
          >
            <Text style={styles.wipeStatsTitle}>🛡️ {t.dataProtection}</Text>
            <View style={styles.wipeStatsRow}>
              <View style={styles.wipeStatItem}>
                <Text style={styles.wipeStatValue}>{totalWipes}</Text>
                <Text style={styles.wipeStatLabel}>{t.filesWiped}</Text>
              </View>
              <View style={styles.wipeStatDivider} />
              <View style={styles.wipeStatItem}>
                <Text style={styles.wipeStatValue}>
                  {formatBytes(totalDataWiped)}
                </Text>
                <Text style={styles.wipeStatLabel}>Data Destroyed</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* Quick Actions */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Quick Actions</Text>
        <View style={styles.quickActionsGrid}>
          <QuickActionCard
            icon={FileX}
            title={t.selectFiles}
            subtitle="Select & delete files"
            onPress={() => router.push("/file-selector")}
            gradient={[colors.error, "#DC2626"]}
          />
          <QuickActionCard
            icon={FolderX}
            title={t.selectFolders}
            subtitle="Delete entire folders"
            onPress={() => router.push("/file-selector")}
            gradient={[colors.warning, "#D97706"]}
          />
          <QuickActionCard
            icon={Trash2}
            title={t.eraseSpace}
            subtitle="Erase unused space"
            onPress={() => router.push("/storage-analyzer")}
            gradient={[colors.primary, colors.primaryVariant]}
          />
          <QuickActionCard
            icon={Database}
            title="Cache Clean"
            subtitle="Clear app caches"
            onPress={() => router.push("/(tabs)/certificates")}
            gradient={[colors.success, "#059669"]}
          />
          <QuickActionCard
            icon={Smartphone}
            title="Full Device Wipe"
            subtitle="⚠️ Erase everything"
            onPress={handleFullDeviceWipe}
            gradient={["#DC2626", "#B91C1C"]}
            isDestructive={true}
          />
        </View>

        {/* Critical Actions */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>⚠️ Critical Actions</Text>
        <View style={styles.criticalSection}>
          <TouchableOpacity onPress={handleFullDeviceWipe} style={styles.criticalActionCard}>
            <LinearGradient
              colors={["#DC2626", "#B91C1C", "#7F1D1D"]}
              style={styles.criticalActionGradient}
            >
              <View style={styles.criticalHeader}>
                <View style={styles.criticalIconContainer}>
                  <Smartphone color="#FFFFFF" size={28} />
                  <View style={styles.warningIndicator}>
                    <AlertTriangle color="#FFFFFF" size={16} />
                  </View>
                </View>
                <View style={styles.criticalInfo}>
                  <Text style={styles.criticalTitle}>Full Device Wipe</Text>
                  <Text style={styles.criticalSubtitle}>Complete device data destruction</Text>
                </View>
              </View>
              
              <View style={styles.criticalWarning}>
                <AlertTriangle color="#FFFFFF" size={20} />
                <Text style={styles.criticalWarningText}>
                  IRREVERSIBLE: This will permanently erase ALL data on your device using military-grade algorithms. Use with extreme caution.
                </Text>
              </View>
              
              <View style={styles.criticalFeatures}>
                <Text style={styles.criticalFeatureText}>• Wipes all personal files and photos</Text>
                <Text style={styles.criticalFeatureText}>• Destroys all app data and settings</Text>
                <Text style={styles.criticalFeatureText}>• Erases system data and accounts</Text>
                <Text style={styles.criticalFeatureText}>• DoD 5220.22-M compliant</Text>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Security Notice */}
        <View style={styles.securityNotice}>
          <LinearGradient
            colors={[colors.card, colors.cardVariant]}
            style={styles.securityGradient}
          >
            <Shield color={colors.success} size={20} />
            <Text style={[styles.securityText, { color: colors.textMuted }]}>
              🔒 {t.localOperations}. Zero-knowledge privacy guaranteed.
            </Text>
          </LinearGradient>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.8)",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  modalContent: {
    borderRadius: 16,
    padding: 24,
    width: "100%",
    maxWidth: 400,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold" as const,
    flex: 1,
    marginLeft: 12,
  },
  closeButton: {
    padding: 4,
  },
  modalText: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 16,
  },
  warningList: {
    marginBottom: 16,
  },
  warningItem: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 4,
  },
  modalWarning: {
    fontSize: 16,
    fontWeight: "bold" as const,
    marginBottom: 16,
    textAlign: "center",
  },
  modalQuestion: {
    fontSize: 16,
    marginBottom: 24,
    textAlign: "center",
  },
  modalButtons: {
    flexDirection: "row",
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  cancelButton: {
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.2)",
  },
  destructiveButton: {
    backgroundColor: "#DC2626",
  },
  modalButtonText: {
    fontSize: 16,
    fontWeight: "600" as const,
  },
  destructiveButtonText: {
    fontSize: 16,
    fontWeight: "600" as const,
    color: "#FFFFFF",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  logo: {
    width: 48,
    height: 48,
    marginRight: 12,
  },
  headerText: {
    flex: 1,
  },
  greeting: {
    fontSize: 28,
    fontWeight: "bold" as const,
  },
  subtitle: {
    fontSize: 14,
    marginTop: 4,
  },
  shieldContainer: {
    borderRadius: 20,
    overflow: "hidden",
  },
  shieldGradient: {
    padding: 12,
  },
  statsContainer: {
    flexDirection: "row",
    paddingHorizontal: 20,
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    borderRadius: 16,
    overflow: "hidden",
  },
  statGradient: {
    padding: 20,
    alignItems: "center",
  },
  statValue: {
    fontSize: 24,
    fontWeight: "bold" as const,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  wipeStatsCard: {
    marginHorizontal: 20,
    borderRadius: 20,
    overflow: "hidden",
    marginBottom: 32,
  },
  wipeStatsGradient: {
    padding: 24,
  },
  wipeStatsTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 16,
    textAlign: "center",
  },
  wipeStatsRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  wipeStatItem: {
    flex: 1,
    alignItems: "center",
  },
  wipeStatValue: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  wipeStatLabel: {
    fontSize: 12,
    color: "#E2E8F0",
    marginTop: 4,
  },
  wipeStatDivider: {
    width: 1,
    height: 40,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    marginHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold" as const,
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 20,
    justifyContent: "space-between",
    marginBottom: 32,
  },
  quickActionCard: {
    width: "48%",
    borderRadius: 16,
    overflow: "hidden",
    position: "relative",
    marginBottom: 16,
  },
  quickActionGradient: {
    padding: 20,
    alignItems: "center",
    minHeight: 120,
    justifyContent: "center",
  },
  quickActionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginTop: 12,
    textAlign: "center",
  },
  quickActionSubtitle: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 4,
    textAlign: "center",
  },
  warningBadge: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: 12,
    padding: 4,
  },
  criticalSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  criticalActionCard: {
    borderRadius: 16,
    overflow: "hidden",
  },
  criticalActionGradient: {
    padding: 20,
  },
  criticalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  criticalIconContainer: {
    position: "relative",
    marginRight: 16,
  },
  warningIndicator: {
    position: "absolute",
    top: -4,
    right: -4,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 2,
  },
  criticalInfo: {
    flex: 1,
  },
  criticalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  criticalSubtitle: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 2,
  },
  criticalWarning: {
    flexDirection: "row",
    alignItems: "flex-start",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  criticalWarningText: {
    fontSize: 12,
    color: "#FFFFFF",
    marginLeft: 8,
    flex: 1,
    lineHeight: 16,
  },
  criticalFeatures: {
    gap: 4,
  },
  criticalFeatureText: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 16,
  },
  securityNotice: {
    marginHorizontal: 20,
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 20,
  },
  securityGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  securityText: {
    fontSize: 14,
    marginLeft: 12,
    flex: 1,
  },
});