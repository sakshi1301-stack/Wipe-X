import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Stack, useRouter } from "expo-router";
import {
  Shield,
  Fingerprint,
  Lock,
  Eye,
  EyeOff,
} from "lucide-react-native";
import * as Haptics from "expo-haptics";

export default function AuthScreen() {
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const correctPin = "1234"; // In real app, this would be stored securely
  const maxAttempts = 3;

  useEffect(() => {
    // Auto-prompt for biometric authentication on mount
    if (Platform.OS !== "web") {
      promptBiometric();
    }
  }, []);

  const performHapticFeedback = (type: "light" | "medium" | "heavy" = "light") => {
    if (Platform.OS !== "web") {
      const feedbackType = {
        light: Haptics.ImpactFeedbackStyle.Light,
        medium: Haptics.ImpactFeedbackStyle.Medium,
        heavy: Haptics.ImpactFeedbackStyle.Heavy,
      }[type];
      Haptics.impactAsync(feedbackType);
    }
  };

  const promptBiometric = async () => {
    // In a real app, you would use expo-local-authentication here
    // For demo purposes, we'll simulate biometric authentication
    Alert.alert(
      "Biometric Authentication",
      "Use your fingerprint or face to unlock SecureWipe",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Simulate Success",
          onPress: () => {
            performHapticFeedback("medium");
            router.replace("/(tabs)");
          },
        },
        {
          text: "Use PIN",
          onPress: () => {
            // User chose to use PIN instead
          },
        },
      ]
    );
  };

  const handlePinInput = (digit: string) => {
    if (isLocked) return;
    
    performHapticFeedback();
    
    if (digit === "backspace") {
      setPin(prev => prev.slice(0, -1));
    } else if (pin.length < 4) {
      const newPin = pin + digit;
      setPin(newPin);
      
      if (newPin.length === 4) {
        validatePin(newPin);
      }
    }
  };

  const validatePin = (inputPin: string) => {
    if (inputPin === correctPin) {
      performHapticFeedback("heavy");
      Alert.alert("Success", "Authentication successful!", [
        {
          text: "Continue",
          onPress: () => router.replace("/(tabs)"),
        },
      ]);
    } else {
      performHapticFeedback("heavy");
      setAttempts(prev => prev + 1);
      setPin("");
      
      if (attempts + 1 >= maxAttempts) {
        setIsLocked(true);
        Alert.alert(
          "Too Many Attempts",
          "App locked due to too many failed attempts. Please try again later.",
          [{ text: "OK" }]
        );
      } else {
        Alert.alert(
          "Incorrect PIN",
          `Wrong PIN. ${maxAttempts - attempts - 1} attempts remaining.`,
          [{ text: "Try Again" }]
        );
      }
    }
  };

  const PinDot = ({ filled }: { filled: boolean }) => (
    <View style={[styles.pinDot, filled && styles.pinDotFilled]}>
      {filled && <View style={styles.pinDotInner} />}
    </View>
  );

  const NumberButton = ({ number, onPress }: { number: string; onPress: () => void }) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={isLocked}
      style={[styles.numberButton, isLocked && styles.disabledButton]}
    >
      <LinearGradient
        colors={["#1E293B", "#334155"]}
        style={styles.numberGradient}
      >
        <Text style={[styles.numberText, isLocked && styles.disabledText]}>
          {number}
        </Text>
      </LinearGradient>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Stack.Screen
        options={{
          headerShown: false,
        }}
      />

      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <LinearGradient
              colors={["#7C3AED", "#3B82F6"]}
              style={styles.logoGradient}
            >
              <Shield color="#FFFFFF" size={32} />
            </LinearGradient>
          </View>
          <Text style={styles.appTitle}>SecureWipe</Text>
          <Text style={styles.authSubtitle}>Enter your PIN to continue</Text>
        </View>

        {/* PIN Display */}
        <View style={styles.pinContainer}>
          <View style={styles.pinDots}>
            {[0, 1, 2, 3].map(index => (
              <PinDot key={index} filled={index < pin.length} />
            ))}
          </View>
          
          {attempts > 0 && (
            <Text style={styles.attemptsText}>
              {maxAttempts - attempts} attempts remaining
            </Text>
          )}
        </View>

        {/* Number Pad */}
        <View style={styles.numberPad}>
          <View style={styles.numberRow}>
            <NumberButton number="1" onPress={() => handlePinInput("1")} />
            <NumberButton number="2" onPress={() => handlePinInput("2")} />
            <NumberButton number="3" onPress={() => handlePinInput("3")} />
          </View>
          <View style={styles.numberRow}>
            <NumberButton number="4" onPress={() => handlePinInput("4")} />
            <NumberButton number="5" onPress={() => handlePinInput("5")} />
            <NumberButton number="6" onPress={() => handlePinInput("6")} />
          </View>
          <View style={styles.numberRow}>
            <NumberButton number="7" onPress={() => handlePinInput("7")} />
            <NumberButton number="8" onPress={() => handlePinInput("8")} />
            <NumberButton number="9" onPress={() => handlePinInput("9")} />
          </View>
          <View style={styles.numberRow}>
            <TouchableOpacity
              onPress={() => setShowPin(!showPin)}
              disabled={isLocked}
              style={[styles.actionButton, isLocked && styles.disabledButton]}
            >
              <LinearGradient
                colors={["#1E293B", "#334155"]}
                style={styles.actionGradient}
              >
                {showPin ? (
                  <EyeOff color={isLocked ? "#64748B" : "#8B5CF6"} size={20} />
                ) : (
                  <Eye color={isLocked ? "#64748B" : "#8B5CF6"} size={20} />
                )}
              </LinearGradient>
            </TouchableOpacity>
            
            <NumberButton number="0" onPress={() => handlePinInput("0")} />
            
            <TouchableOpacity
              onPress={() => handlePinInput("backspace")}
              disabled={isLocked || pin.length === 0}
              style={[
                styles.actionButton,
                (isLocked || pin.length === 0) && styles.disabledButton,
              ]}
            >
              <LinearGradient
                colors={["#1E293B", "#334155"]}
                style={styles.actionGradient}
              >
                <Text style={[
                  styles.backspaceText,
                  (isLocked || pin.length === 0) && styles.disabledText,
                ]}>
                  ⌫
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>

        {/* Biometric Button */}
        <TouchableOpacity
          onPress={promptBiometric}
          disabled={isLocked}
          style={[styles.biometricButton, isLocked && styles.disabledButton]}
        >
          <LinearGradient
            colors={isLocked ? ["#374151", "#4B5563"] : ["#8B5CF6", "#7C3AED"]}
            style={styles.biometricGradient}
          >
            <Fingerprint color="#FFFFFF" size={24} />
            <Text style={styles.biometricText}>Use Biometric</Text>
          </LinearGradient>
        </TouchableOpacity>

        {/* Security Notice */}
        <View style={styles.securityNotice}>
          <LinearGradient
            colors={["#1E293B", "#334155"]}
            style={styles.securityGradient}
          >
            <Lock color="#8B5CF6" size={16} />
            <Text style={styles.securityText}>
              Your data is protected with military-grade encryption
            </Text>
          </LinearGradient>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0F172A",
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
  },
  header: {
    alignItems: "center",
    marginBottom: 48,
  },
  logoContainer: {
    borderRadius: 24,
    overflow: "hidden",
    marginBottom: 16,
  },
  logoGradient: {
    padding: 16,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  authSubtitle: {
    fontSize: 16,
    color: "#94A3B8",
    textAlign: "center",
  },
  pinContainer: {
    alignItems: "center",
    marginBottom: 48,
  },
  pinDots: {
    flexDirection: "row",
    gap: 16,
    marginBottom: 16,
  },
  pinDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: "#374151",
    alignItems: "center",
    justifyContent: "center",
  },
  pinDotFilled: {
    borderColor: "#8B5CF6",
    backgroundColor: "#8B5CF6",
  },
  pinDotInner: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#FFFFFF",
  },
  attemptsText: {
    fontSize: 14,
    color: "#EF4444",
    textAlign: "center",
  },
  numberPad: {
    marginBottom: 32,
  },
  numberRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  numberButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    overflow: "hidden",
  },
  numberGradient: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  numberText: {
    fontSize: 24,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  actionButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    overflow: "hidden",
  },
  actionGradient: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  backspaceText: {
    fontSize: 20,
    color: "#FFFFFF",
  },
  disabledButton: {
    opacity: 0.5,
  },
  disabledText: {
    color: "#64748B",
  },
  biometricButton: {
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 24,
  },
  biometricGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  biometricText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
    marginLeft: 8,
  },
  securityNotice: {
    borderRadius: 12,
    overflow: "hidden",
  },
  securityGradient: {
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  securityText: {
    fontSize: 12,
    color: "#94A3B8",
    marginLeft: 8,
    textAlign: "center",
  },
});