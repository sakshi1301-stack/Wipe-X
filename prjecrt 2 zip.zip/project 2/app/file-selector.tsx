import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Stack, useRouter } from "expo-router";
import {
  ArrowLeft,
  File,
  Folder,
  Check,
  HardDrive,
  Trash2,
  AlertTriangle,
} from "lucide-react-native";
import * as Haptics from "expo-haptics";

interface FileItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size: number;
  path: string;
  selected: boolean;
}

export default function FileSelectorScreen() {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [selectedCount, setSelectedCount] = useState(0);
  const [totalSize, setTotalSize] = useState(0);
  const insets = useSafeAreaInsets();
  const router = useRouter();

  useEffect(() => {
    // Mock file system data - in real app, this would scan actual files
    const mockFiles: FileItem[] = [
      {
        id: "1",
        name: "Downloads",
        type: "folder",
        size: 157286400, // 150 MB
        path: "/storage/emulated/0/Download",
        selected: false,
      },
      {
        id: "2",
        name: "Pictures",
        type: "folder",
        size: 524288000, // 500 MB
        path: "/storage/emulated/0/Pictures",
        selected: false,
      },
      {
        id: "3",
        name: "document.pdf",
        type: "file",
        size: 2097152, // 2 MB
        path: "/storage/emulated/0/Documents/document.pdf",
        selected: false,
      },
      {
        id: "4",
        name: "video.mp4",
        type: "file",
        size: 104857600, // 100 MB
        path: "/storage/emulated/0/Movies/video.mp4",
        selected: false,
      },
      {
        id: "5",
        name: "Music",
        type: "folder",
        size: 314572800, // 300 MB
        path: "/storage/emulated/0/Music",
        selected: false,
      },
      {
        id: "6",
        name: "cache_file.tmp",
        type: "file",
        size: 52428800, // 50 MB
        path: "/data/data/com.app/cache/cache_file.tmp",
        selected: false,
      },
    ];
    setFiles(mockFiles);
  }, []);

  const performHapticFeedback = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const toggleFileSelection = (fileId: string) => {
    performHapticFeedback();
    
    setFiles(prevFiles => {
      const updatedFiles = prevFiles.map(file => {
        if (file.id === fileId) {
          return { ...file, selected: !file.selected };
        }
        return file;
      });
      
      const selected = updatedFiles.filter(f => f.selected);
      setSelectedCount(selected.length);
      setTotalSize(selected.reduce((sum, f) => sum + f.size, 0));
      
      return updatedFiles;
    });
  };

  const selectAll = () => {
    performHapticFeedback();
    
    setFiles(prevFiles => {
      const allSelected = prevFiles.every(f => f.selected);
      const updatedFiles = prevFiles.map(file => ({
        ...file,
        selected: !allSelected,
      }));
      
      if (allSelected) {
        setSelectedCount(0);
        setTotalSize(0);
      } else {
        setSelectedCount(updatedFiles.length);
        setTotalSize(updatedFiles.reduce((sum, f) => sum + f.size, 0));
      }
      
      return updatedFiles;
    });
  };

  const proceedToWipe = () => {
    if (selectedCount === 0) {
      Alert.alert("No Selection", "Please select files or folders to wipe.");
      return;
    }

    Alert.alert(
      "Confirm Wipe",
      `Are you sure you want to securely wipe ${selectedCount} item(s) (${formatBytes(totalSize)})? This action cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Wipe",
          style: "destructive",
          onPress: () => {
            const selectedFiles = files.filter(f => f.selected);
            router.push({
              pathname: "/wipe-progress",
              params: {
                files: JSON.stringify(selectedFiles.map(f => ({ name: f.name, size: f.size, type: f.type }))),
                totalSize: totalSize.toString(),
              },
            });
          },
        },
      ]
    );
  };

  const FileItemComponent = ({ item }: { item: FileItem }) => {
    const Icon = item.type === "folder" ? Folder : File;
    const isSelected = item.selected;

    return (
      <TouchableOpacity
        onPress={() => toggleFileSelection(item.id)}
        style={styles.fileItem}
      >
        <LinearGradient
          colors={isSelected ? ["#7C3AED", "#3B82F6"] : ["#1E293B", "#334155"]}
          style={styles.fileGradient}
        >
          <View style={styles.fileContent}>
            <View style={styles.fileLeft}>
              <View style={[styles.iconContainer, isSelected && styles.selectedIcon]}>
                <Icon color={isSelected ? "#FFFFFF" : "#8B5CF6"} size={20} />
              </View>
              <View style={styles.fileInfo}>
                <Text style={[styles.fileName, isSelected && styles.selectedText]}>
                  {item.name}
                </Text>
                <Text style={[styles.filePath, isSelected && styles.selectedSubtext]}>
                  {item.path}
                </Text>
              </View>
            </View>
            <View style={styles.fileRight}>
              <Text style={[styles.fileSize, isSelected && styles.selectedText]}>
                {formatBytes(item.size)}
              </Text>
              {isSelected && (
                <View style={styles.checkContainer}>
                  <Check color="#FFFFFF" size={16} />
                </View>
              )}
            </View>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Stack.Screen
        options={{
          headerShown: true,
          headerTitle: "Select Files",
          headerStyle: { backgroundColor: "#0F172A" },
          headerTintColor: "#FFFFFF",
          headerTitleStyle: { fontWeight: "bold" },
          headerLeft: () => (
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <ArrowLeft color="#FFFFFF" size={24} />
            </TouchableOpacity>
          ),
        }}
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Selection Summary */}
        <View style={styles.summaryCard}>
          <LinearGradient
            colors={["#7C3AED", "#3B82F6"]}
            style={styles.summaryGradient}
          >
            <View style={styles.summaryContent}>
              <View style={styles.summaryItem}>
                <Text style={styles.summaryValue}>{selectedCount}</Text>
                <Text style={styles.summaryLabel}>Selected</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <Text style={styles.summaryValue}>{formatBytes(totalSize)}</Text>
                <Text style={styles.summaryLabel}>Total Size</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity onPress={selectAll} style={styles.selectAllButton}>
            <LinearGradient
              colors={["#1E293B", "#334155"]}
              style={styles.actionGradient}
            >
              <HardDrive color="#8B5CF6" size={20} />
              <Text style={styles.actionText}>Select All</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Files List */}
        <Text style={styles.sectionTitle}>Files & Folders</Text>
        
        {files.map((item) => (
          <FileItemComponent key={item.id} item={item} />
        ))}

        {/* Warning */}
        <View style={styles.warningCard}>
          <LinearGradient
            colors={["#DC2626", "#B91C1C"]}
            style={styles.warningGradient}
          >
            <AlertTriangle color="#FFFFFF" size={20} />
            <View style={styles.warningText}>
              <Text style={styles.warningTitle}>Permanent Deletion</Text>
              <Text style={styles.warningDescription}>
                Wiped files cannot be recovered. Make sure you have backups of important data.
              </Text>
            </View>
          </LinearGradient>
        </View>
      </ScrollView>

      {/* Bottom Action Bar */}
      {selectedCount > 0 && (
        <View style={styles.bottomBar}>
          <LinearGradient
            colors={["#0F172A", "#1E293B"]}
            style={styles.bottomGradient}
          >
            <TouchableOpacity onPress={proceedToWipe} style={styles.wipeButton}>
              <LinearGradient
                colors={["#EF4444", "#DC2626"]}
                style={styles.wipeGradient}
              >
                <Trash2 color="#FFFFFF" size={20} />
                <Text style={styles.wipeButtonText}>Wipe Selected</Text>
              </LinearGradient>
            </TouchableOpacity>
          </LinearGradient>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0F172A",
  },
  backButton: {
    padding: 8,
  },
  summaryCard: {
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
    overflow: "hidden",
  },
  summaryGradient: {
    padding: 20,
  },
  summaryContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  summaryItem: {
    flex: 1,
    alignItems: "center",
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  summaryLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 4,
  },
  summaryDivider: {
    width: 1,
    height: 40,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    marginHorizontal: 20,
  },
  actionButtons: {
    paddingHorizontal: 20,
    marginTop: 20,
  },
  selectAllButton: {
    borderRadius: 12,
    overflow: "hidden",
  },
  actionGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  actionText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
    marginLeft: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
    paddingHorizontal: 20,
    marginTop: 32,
    marginBottom: 16,
  },
  fileItem: {
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 12,
    overflow: "hidden",
  },
  fileGradient: {
    padding: 16,
  },
  fileContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  fileLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: "rgba(139, 92, 246, 0.1)",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  selectedIcon: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  },
  fileInfo: {
    flex: 1,
  },
  fileName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  filePath: {
    fontSize: 12,
    color: "#94A3B8",
    marginTop: 2,
  },
  selectedText: {
    color: "#FFFFFF",
  },
  selectedSubtext: {
    color: "rgba(255, 255, 255, 0.8)",
  },
  fileRight: {
    alignItems: "flex-end",
  },
  fileSize: {
    fontSize: 14,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  checkContainer: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  warningCard: {
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 12,
    overflow: "hidden",
  },
  warningGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  warningText: {
    marginLeft: 12,
    flex: 1,
  },
  warningTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 4,
  },
  warningDescription: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 20,
  },
  bottomBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
  },
  bottomGradient: {
    padding: 20,
    paddingBottom: 34,
  },
  wipeButton: {
    borderRadius: 16,
    overflow: "hidden",
  },
  wipeGradient: {
    padding: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  wipeButtonText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginLeft: 8,
  },
});