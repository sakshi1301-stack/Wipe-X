import React from 'react';
import HomeScreen from '../home';

export default function HomeTab() {
  return <HomeScreen />;
}