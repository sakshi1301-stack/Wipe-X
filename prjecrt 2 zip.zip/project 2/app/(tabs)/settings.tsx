import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Modal,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Settings,
  Shield,
  Palette,
  Lock,
  Globe,
  Info,
  ChevronRight,
  Sun,
  Moon,
  Smartphone,
  X,
} from 'lucide-react-native';
import { useSettingsStore, Language, Theme } from '@/store/settings-store';
import { useTheme } from '@/store/theme-context';
import { useTranslations } from '@/store/translations';

export default function SettingsScreen() {
  const {
    theme,
    wipeAlgorithm,
    requireAuth,
    language,
    setTheme,
    toggleAuth,
    setWipeAlgorithm,
    setLanguage,
  } = useSettingsStore();
  const { colors } = useTheme();
  const t = useTranslations(language);
  const insets = useSafeAreaInsets();
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);

  const SettingCard = ({
    icon: Icon,
    title,
    subtitle,
    onPress,
    rightElement,
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity onPress={onPress} disabled={!onPress} style={styles.settingCard}>
      <LinearGradient colors={[colors.card, colors.cardVariant]} style={styles.settingGradient}>
        <View style={styles.settingContent}>
          <View style={styles.settingLeft}>
            <View style={[styles.settingIconContainer, { backgroundColor: colors.primary + '20' }]}>
              <Icon color={colors.primary} size={20} />
            </View>
            <View style={styles.settingText}>
              <Text style={[styles.settingTitle, { color: colors.text }]}>{title}</Text>
              {subtitle && <Text style={[styles.settingSubtitle, { color: colors.textMuted }]}>{subtitle}</Text>}
            </View>
          </View>
          <View style={styles.settingRight}>
            {rightElement && rightElement}
            {onPress && <ChevronRight color={colors.textMuted} size={20} />}
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );

  const algorithms = [
    { id: 'fast', name: t.fastWipe, description: t.singlePass },
    { id: 'dod', name: t.dodStandard, description: t.threePassMilitary },
    { id: 'gutmann', name: t.gutmannMethod, description: t.thirtyFivePass },
    { id: 'random', name: t.randomOverwrite, description: t.sevenPassRandom },
  ];

  const themes = [
    { id: 'light', name: t.lightMode, icon: Sun },
    { id: 'dark', name: t.darkMode, icon: Moon },
    { id: 'auto', name: t.autoMode, icon: Smartphone },
  ];

  const languages = [
    { id: 'en', name: 'English', flag: '🇺🇸' },
    { id: 'es', name: 'Español', flag: '🇪🇸' },
    { id: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
  ];

  const ThemeModal = () => (
    <Modal
      visible={showThemeModal}
      transparent
      animationType="fade"
      onRequestClose={() => setShowThemeModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t.theme}</Text>
            <TouchableOpacity onPress={() => setShowThemeModal(false)}>
              <X color={colors.textMuted} size={24} />
            </TouchableOpacity>
          </View>
          {themes.map((themeOption) => {
            const IconComponent = themeOption.icon;
            return (
              <TouchableOpacity
                key={themeOption.id}
                style={[
                  styles.modalOption,
                  theme === themeOption.id && { backgroundColor: colors.primary + '20' }
                ]}
                onPress={() => {
                  setTheme(themeOption.id as Theme);
                  setShowThemeModal(false);
                }}
              >
                <IconComponent color={colors.primary} size={20} />
                <Text style={[styles.modalOptionText, { color: colors.text }]}>
                  {themeOption.name}
                </Text>
                {theme === themeOption.id && (
                  <View style={[styles.selectedIndicator, { backgroundColor: colors.primary }]} />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    </Modal>
  );

  const LanguageModal = () => (
    <Modal
      visible={showLanguageModal}
      transparent
      animationType="fade"
      onRequestClose={() => setShowLanguageModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
          <View style={styles.modalHeader}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t.language}</Text>
            <TouchableOpacity onPress={() => setShowLanguageModal(false)}>
              <X color={colors.textMuted} size={24} />
            </TouchableOpacity>
          </View>
          {languages.map((lang) => (
            <TouchableOpacity
              key={lang.id}
              style={[
                styles.modalOption,
                language === lang.id && { backgroundColor: colors.primary + '20' }
              ]}
              onPress={() => {
                setLanguage(lang.id as Language);
                setShowLanguageModal(false);
              }}
            >
              <Text style={styles.flagText}>{lang.flag}</Text>
              <Text style={[styles.modalOptionText, { color: colors.text }]}>
                {lang.name}
              </Text>
              {language === lang.id && (
                <View style={[styles.selectedIndicator, { backgroundColor: colors.primary }]} />
              )}
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </Modal>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingHorizontal: 20,
      paddingTop: 20,
      paddingBottom: 30,
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold' as const,
    },
    subtitle: {
      fontSize: 14,
      marginTop: 4,
    },
    settingsContainer: {
      borderRadius: 20,
      overflow: 'hidden',
    },
    settingsGradient: {
      padding: 12,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: 'bold' as const,
      paddingHorizontal: 20,
      marginBottom: 16,
      marginTop: 8,
    },
    settingCard: {
      marginHorizontal: 20,
      marginBottom: 12,
      borderRadius: 12,
      overflow: 'hidden',
    },
    settingGradient: {
      padding: 16,
    },
    settingContent: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    settingLeft: {
      flexDirection: 'row',
      alignItems: 'center',
      flex: 1,
    },
    settingIconContainer: {
      width: 40,
      height: 40,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
    },
    settingText: {
      flex: 1,
    },
    settingTitle: {
      fontSize: 16,
      fontWeight: '600' as const,
    },
    settingSubtitle: {
      fontSize: 12,
      marginTop: 2,
    },
    settingRight: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    algorithmCard: {
      marginHorizontal: 20,
      borderRadius: 16,
      overflow: 'hidden',
      marginTop: 20,
      marginBottom: 20,
    },
    algorithmGradient: {
      padding: 20,
    },
    algorithmTitle: {
      fontSize: 18,
      fontWeight: 'bold' as const,
      color: '#FFFFFF',
      marginBottom: 12,
    },
    algorithmDescription: {
      fontSize: 14,
      color: 'rgba(255, 255, 255, 0.9)',
      lineHeight: 20,
    },
    privacyNotice: {
      marginHorizontal: 20,
      borderRadius: 12,
      overflow: 'hidden',
      marginBottom: 20,
    },
    privacyGradient: {
      padding: 16,
      flexDirection: 'row',
      alignItems: 'flex-start',
    },
    privacyText: {
      marginLeft: 12,
      flex: 1,
    },
    privacyTitle: {
      fontSize: 16,
      fontWeight: 'bold' as const,
      marginBottom: 4,
    },
    privacyDescription: {
      fontSize: 14,
      lineHeight: 20,
    },
    modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      justifyContent: 'center',
      alignItems: 'center',
    },
    modalContent: {
      width: '80%',
      borderRadius: 16,
      padding: 20,
      maxHeight: '70%',
    },
    modalHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 20,
    },
    modalTitle: {
      fontSize: 20,
      fontWeight: 'bold' as const,
    },
    modalOption: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 16,
      paddingHorizontal: 12,
      borderRadius: 8,
      marginBottom: 8,
    },
    modalOptionText: {
      fontSize: 16,
      marginLeft: 12,
      flex: 1,
    },
    flagText: {
      fontSize: 20,
    },
    selectedIndicator: {
      width: 8,
      height: 8,
      borderRadius: 4,
    },
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>{t.settings}</Text>
            <Text style={[styles.subtitle, { color: colors.textMuted }]}>Customize your security preferences</Text>
          </View>
          <View style={styles.settingsContainer}>
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              style={styles.settingsGradient}
            >
              <Settings color="#FFFFFF" size={24} />
            </LinearGradient>
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.text }]}>{t.security}</Text>
        
        <SettingCard
          icon={Shield}
          title={t.wipeAlgorithm}
          subtitle={algorithms.find(a => a.id === wipeAlgorithm)?.name}
          onPress={() => {
            const currentIndex = algorithms.findIndex(a => a.id === wipeAlgorithm);
            const nextIndex = (currentIndex + 1) % algorithms.length;
            setWipeAlgorithm(algorithms[nextIndex].id as any);
          }}
        />

        <SettingCard
          icon={Lock}
          title={t.requireAuthentication}
          subtitle={t.protectApp}
          rightElement={
            <Switch
              value={requireAuth}
              onValueChange={toggleAuth}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={requireAuth ? '#FFFFFF' : colors.textMuted}
            />
          }
        />

        <Text style={[styles.sectionTitle, { color: colors.text }]}>{t.appearance}</Text>
        
        <SettingCard
          icon={Palette}
          title={t.theme}
          subtitle={themes.find(t => t.id === theme)?.name}
          onPress={() => setShowThemeModal(true)}
        />



        <Text style={[styles.sectionTitle, { color: colors.text }]}>{t.general}</Text>
        
        <SettingCard
          icon={Globe}
          title={t.language}
          subtitle={languages.find(l => l.id === language)?.name}
          onPress={() => setShowLanguageModal(true)}
        />

        <SettingCard
          icon={Info}
          title={t.about}
          subtitle={t.version}
          onPress={() => {
            Alert.alert(
              t.about,
              `${t.about} v1.0.0\n\n${t.militaryGrade}\n\n${t.privacyFirst}:\n• DoD 5220.22-M standard wiping\n• Biometric authentication\n• Real-time progress tracking\n• ${t.dataProtection}`,
              [{ text: 'OK' }]
            );
          }}
        />

        <View style={styles.algorithmCard}>
          <LinearGradient
            colors={[colors.primary, colors.secondary]}
            style={styles.algorithmGradient}
          >
            <Text style={styles.algorithmTitle}>
              {t.algorithm}: {algorithms.find(a => a.id === wipeAlgorithm)?.name}
            </Text>
            <Text style={styles.algorithmDescription}>
              {algorithms.find(a => a.id === wipeAlgorithm)?.description}
              {wipeAlgorithm === 'dod' && (
                '\n\nThis military-grade algorithm performs 3 passes:\n• Pass 1: Write binary zeros\n• Pass 2: Write binary ones\n• Pass 3: Write random data'
              )}
              {wipeAlgorithm === 'gutmann' && (
                '\n\nThe most secure algorithm with 35 passes of different patterns. Extremely thorough but slower.'
              )}
              {wipeAlgorithm === 'fast' && (
                '\n\nQuick single-pass overwrite. Suitable for non-sensitive data or when speed is priority.'
              )}
              {wipeAlgorithm === 'random' && (
                '\n\n7-pass random data overwrite. Good balance between security and performance.'
              )}
            </Text>
          </LinearGradient>
        </View>

        <View style={styles.privacyNotice}>
          <LinearGradient
            colors={[colors.card, colors.cardVariant]}
            style={styles.privacyGradient}
          >
            <Shield color={colors.success} size={20} />
            <View style={styles.privacyText}>
              <Text style={[styles.privacyTitle, { color: colors.text }]}>{t.privacyFirst}</Text>
              <Text style={[styles.privacyDescription, { color: colors.textMuted }]}>
                {t.localOperations}. No data is sent to external servers.
              </Text>
            </View>
          </LinearGradient>
        </View>
      </ScrollView>

      <ThemeModal />
      <LanguageModal />
    </View>
  );
}