import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  History,
  FileX,
  FolderX,
  Database,
  Trash2,
  Calendar,

  Shield,
} from "lucide-react-native";
import { useWipeStore } from "@/store/wipe-store";
import { useTheme } from "@/store/theme-context";
import { useSettingsStore } from "@/store/settings-store";
import { useTranslations } from "@/store/translations";

export default function HistoryScreen() {
  const { wipeHistory } = useWipeStore();
  const { colors } = useTheme();
  const { language } = useSettingsStore();
  const t = useTranslations(language);
  const insets = useSafeAreaInsets();

  const getWipeIcon = (type: string) => {
    switch (type) {
      case "file":
        return FileX;
      case "folder":
        return FolderX;
      case "cache":
        return Database;
      default:
        return Trash2;
    }
  };

  const getWipeColor = (type: string): readonly [string, string, ...string[]] => {
    switch (type) {
      case "file":
        return [colors.error, "#DC2626"];
      case "folder":
        return [colors.warning, "#D97706"];
      case "cache":
        return [colors.success, "#059669"];
      default:
        return [colors.primary, colors.primaryVariant];
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const HistoryCard = ({ item }: { item: any }) => {
    const Icon = getWipeIcon(item.type);
    const gradientColors = getWipeColor(item.type);

    return (
      <View style={styles.historyCard}>
        <LinearGradient colors={[colors.card, colors.cardVariant]} style={styles.cardGradient}>
          <View style={styles.cardHeader}>
            <View style={styles.iconContainer}>
              <LinearGradient colors={gradientColors} style={styles.iconGradient}>
                <Icon color="#FFFFFF" size={20} />
              </LinearGradient>
            </View>
            <View style={styles.cardInfo}>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
              <Text style={[styles.cardSubtitle, { color: colors.textMuted }]}>{item.algorithm}</Text>
            </View>
            <View style={styles.cardMeta}>
              <Text style={[styles.cardSize, { color: colors.text }]}>{formatBytes(item.size)}</Text>
              <Text style={[styles.cardTime, { color: colors.textMuted }]}>{formatTime(item.date)}</Text>
            </View>
          </View>
          <View style={styles.cardFooter}>
            <View style={styles.dateContainer}>
              <Calendar color={colors.textMuted} size={14} />
              <Text style={[styles.dateText, { color: colors.textMuted }]}>{formatDate(item.date)}</Text>
            </View>
            <View style={styles.statusContainer}>
              <Shield color={colors.success} size={14} />
              <Text style={[styles.statusText, { color: colors.success }]}>Secure</Text>
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>{t.wipeHistory}</Text>
            <Text style={[styles.subtitle, { color: colors.textMuted }]}>Track your secure deletions</Text>
          </View>
          <View style={styles.historyContainer}>
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              style={styles.historyGradient}
            >
              <History color="#FFFFFF" size={24} />
            </LinearGradient>
          </View>
        </View>

        {/* Summary Stats */}
        <View style={styles.summaryCard}>
          <LinearGradient
            colors={[colors.primary, colors.secondary]}
            style={styles.summaryGradient}
          >
            <Text style={styles.summaryTitle}>Today&apos;s Activity</Text>
            <View style={styles.summaryStats}>
              <View style={styles.summaryItem}>
                <Text style={styles.summaryValue}>12</Text>
                <Text style={styles.summaryLabel}>Files Wiped</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <Text style={styles.summaryValue}>2.4 GB</Text>
                <Text style={styles.summaryLabel}>Data Secured</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* History List */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Recent Activity</Text>
        
        {wipeHistory.length === 0 ? (
          <View style={styles.emptyState}>
            <LinearGradient
              colors={[colors.card, colors.cardVariant]}
              style={styles.emptyGradient}
            >
              <History color={colors.textMuted} size={48} />
              <Text style={[styles.emptyTitle, { color: colors.text }]}>{t.noHistory}</Text>
              <Text style={[styles.emptyDescription, { color: colors.textMuted }]}>
                Your secure deletion history will appear here
              </Text>
            </LinearGradient>
          </View>
        ) : (
          wipeHistory.map((item, index) => (
            <HistoryCard key={index} item={item} />
          ))
        )}

        {/* Export Options */}
        <TouchableOpacity style={styles.exportButton}>
          <LinearGradient
            colors={[colors.card, colors.cardVariant]}
            style={styles.exportGradient}
          >
            <Text style={[styles.exportText, { color: colors.text }]}>Export Wipe Log</Text>
            <Text style={[styles.exportSubtext, { color: colors.textMuted }]}>
              Generate a detailed report of all wipe operations
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold" as const,
  },
  subtitle: {
    fontSize: 14,
    marginTop: 4,
  },
  historyContainer: {
    borderRadius: 20,
    overflow: "hidden",
  },
  historyGradient: {
    padding: 12,
  },
  summaryCard: {
    marginHorizontal: 20,
    borderRadius: 20,
    overflow: "hidden",
    marginBottom: 32,
  },
  summaryGradient: {
    padding: 24,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 16,
    textAlign: "center",
  },
  summaryStats: {
    flexDirection: "row",
    alignItems: "center",
  },
  summaryItem: {
    flex: 1,
    alignItems: "center",
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  summaryLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 4,
  },
  summaryDivider: {
    width: 1,
    height: 40,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    marginHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold" as const,
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  historyCard: {
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 16,
    overflow: "hidden",
  },
  cardGradient: {
    padding: 16,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  iconContainer: {
    borderRadius: 12,
    overflow: "hidden",
    marginRight: 12,
  },
  iconGradient: {
    padding: 8,
  },
  cardInfo: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "bold" as const,
  },
  cardSubtitle: {
    fontSize: 12,
    marginTop: 2,
  },
  cardMeta: {
    alignItems: "flex-end",
  },
  cardSize: {
    fontSize: 14,
    fontWeight: "600" as const,
  },
  cardTime: {
    fontSize: 12,
    marginTop: 2,
  },
  cardFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  dateContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  dateText: {
    fontSize: 12,
    marginLeft: 6,
  },
  statusContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  statusText: {
    fontSize: 12,
    marginLeft: 6,
    fontWeight: "600" as const,
  },
  emptyState: {
    marginHorizontal: 20,
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 20,
  },
  emptyGradient: {
    padding: 40,
    alignItems: "center",
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "bold" as const,
    marginTop: 16,
  },
  emptyDescription: {
    fontSize: 14,
    textAlign: "center" as const,
    marginTop: 8,
  },
  exportButton: {
    marginHorizontal: 20,
    borderRadius: 12,
    overflow: "hidden",
    marginTop: 20,
    marginBottom: 20,
  },
  exportGradient: {
    padding: 16,
    alignItems: "center",
  },
  exportText: {
    fontSize: 16,
    fontWeight: "bold" as const,
  },
  exportSubtext: {
    fontSize: 12,
    marginTop: 4,
    textAlign: "center" as const,
  },
});