import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Share,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Award,
  Download,
  FileText,
  Code,
  Calendar,
  Shield,
  CheckCircle,
  Plus,
} from 'lucide-react-native';
import { useTheme } from '@/store/theme-context';
import { useSettingsStore } from '@/store/settings-store';
import { useTranslations } from '@/store/translations';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface WipeCertificate {
  id: string;
  fileName: string;
  algorithm: string;
  timestamp: string;
  size: string;
  hash: string;
  passes: number;
  verified: boolean;
}

export default function CertificatesScreen() {
  const { colors } = useTheme();
  const { language } = useSettingsStore();
  const t = useTranslations(language);
  const insets = useSafeAreaInsets();
  const [certificates, setCertificates] = useState<WipeCertificate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCertificates();
  }, []);

  const loadCertificates = async () => {
    try {
      const stored = await AsyncStorage.getItem('wipeCertificates');
      if (stored) {
        setCertificates(JSON.parse(stored));
      }
    } catch (error) {
      console.log('Error loading certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSampleCertificate = async () => {
    const sampleFiles = [
      { name: 'confidential_report.pdf', size: '2.4 MB' },
      { name: 'financial_data.xlsx', size: '1.8 MB' },
      { name: 'personal_photos.zip', size: '15.2 MB' },
      { name: 'secure_backup.tar', size: '8.7 MB' },
      { name: 'private_keys.txt', size: '0.3 MB' },
    ];
    
    const algorithms = ['DoD 5220.22-M', 'Gutmann Method', 'Random Overwrite', 'Fast Wipe'];
    const passes = [3, 35, 7, 1];
    
    const randomFile = sampleFiles[Math.floor(Math.random() * sampleFiles.length)];
    const randomAlgorithm = algorithms[Math.floor(Math.random() * algorithms.length)];
    const algorithmIndex = algorithms.indexOf(randomAlgorithm);
    
    const newCertificate: WipeCertificate = {
      id: `WX-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      fileName: randomFile.name,
      algorithm: randomAlgorithm,
      timestamp: new Date().toISOString(),
      size: randomFile.size,
      hash: 'SHA256:' + Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      passes: passes[algorithmIndex],
      verified: true,
    };

    const updatedCertificates = [newCertificate, ...certificates];
    setCertificates(updatedCertificates);
    
    try {
      await AsyncStorage.setItem('wipeCertificates', JSON.stringify(updatedCertificates));
      Alert.alert(
        '🏆 Premium Certificate Generated',
        `${t.certificateGenerated}\n\nFile: ${newCertificate.fileName}\nAlgorithm: ${newCertificate.algorithm}\nPasses: ${newCertificate.passes}`,
        [{ text: 'Excellent!' }]
      );
    } catch (error) {
      console.log('Error saving certificate:', error);
    }
  };

  const exportToPDF = (certificate: WipeCertificate) => {
    const pdfContent = `
╔══════════════════════════════════════════════════════════════╗
║                    🔒 WIPEX PREMIUM CERTIFICATE              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  SECURE DATA DESTRUCTION CERTIFICATE                         ║
║  Military-Grade Compliance Verification                      ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Certificate ID: ${certificate.id.padEnd(40)}║
║  File Name: ${certificate.fileName.padEnd(45)}║
║  Algorithm: ${certificate.algorithm.padEnd(45)}║
║  Timestamp: ${new Date(certificate.timestamp).toLocaleString().padEnd(40)}║
║  File Size: ${certificate.size.padEnd(45)}║
║  Hash: ${certificate.hash.substring(0, 40).padEnd(40)}║
║  Passes: ${certificate.passes.toString().padEnd(48)}║
║  Status: ${(certificate.verified ? '✅ VERIFIED & COMPLIANT' : '❌ UNVERIFIED').padEnd(43)}║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🛡️ CERTIFICATION STATEMENT                                  ║
║                                                              ║
║  This premium certificate confirms that the specified        ║
║  file has been permanently and irreversibly destroyed        ║
║  using military-grade data sanitization algorithms in        ║
║  compliance with DoD 5220.22-M standards.                   ║
║                                                              ║
║  The data destruction process has been verified and          ║
║  cannot be recovered by any known forensic methods.          ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Generated by: WipeX Premium v1.0.0                         ║
║  Compliance: DoD 5220.22-M, NIST 800-88                     ║
║  Generated: ${new Date().toLocaleString().padEnd(42)}║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    `.trim();

    if (Platform.OS === 'web') {
      const blob = new Blob([pdfContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `WipeX_Premium_Certificate_${certificate.id}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      Share.share({
        message: pdfContent,
        title: `WipeX Premium Certificate - ${certificate.fileName}`,
      });
    }
  };

  const exportToJSON = (certificate: WipeCertificate) => {
    const jsonContent = JSON.stringify({
      wipeXCertificate: {
        version: '1.0.0',
        type: 'PREMIUM_DATA_DESTRUCTION_CERTIFICATE',
        metadata: {
          id: certificate.id,
          fileName: certificate.fileName,
          algorithm: certificate.algorithm,
          timestamp: certificate.timestamp,
          size: certificate.size,
          hash: certificate.hash,
          passes: certificate.passes,
          verified: certificate.verified,
          generatedAt: new Date().toISOString(),
          generatedBy: 'WipeX Premium v1.0.0',
        },
        compliance: {
          standards: ['DoD 5220.22-M', 'NIST 800-88'],
          certificationLevel: 'MILITARY_GRADE',
          verificationStatus: certificate.verified ? 'VERIFIED' : 'UNVERIFIED',
          recoveryPossibility: 'IMPOSSIBLE',
        },
        security: {
          encryptionUsed: true,
          multiPassOverwrite: true,
          forensicResistant: true,
          tamperEvident: true,
        },
        signature: {
          algorithm: 'SHA-256',
          hash: certificate.hash,
          timestamp: certificate.timestamp,
        }
      }
    }, null, 2);

    if (Platform.OS === 'web') {
      const blob = new Blob([jsonContent], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `WipeX_Premium_Certificate_${certificate.id}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      Share.share({
        message: jsonContent,
        title: `WipeX Premium Certificate JSON - ${certificate.fileName}`,
      });
    }
  };

  const CertificateCard = ({ certificate }: { certificate: WipeCertificate }) => (
    <View style={[styles.certificateCard, { borderColor: colors.border }]}>
      <LinearGradient
        colors={[colors.card, colors.cardVariant]}
        style={styles.certificateGradient}
      >
        <View style={styles.certificateHeader}>
          <View style={styles.certificateIcon}>
            <Award color={colors.primary} size={24} />
          </View>
          <View style={styles.certificateInfo}>
            <Text style={[styles.certificateTitle, { color: colors.text }]}>
              {certificate.fileName}
            </Text>
            <Text style={[styles.certificateSubtitle, { color: colors.textMuted }]}>
              {certificate.algorithm} • {certificate.passes} passes
            </Text>
          </View>
          {certificate.verified && (
            <CheckCircle color={colors.success} size={20} />
          )}
        </View>

        <View style={styles.certificateDetails}>
          <View style={styles.detailRow}>
            <Calendar color={colors.textMuted} size={16} />
            <Text style={[styles.detailText, { color: colors.textSecondary }]}>
              {new Date(certificate.timestamp).toLocaleDateString()} {new Date(certificate.timestamp).toLocaleTimeString()}
            </Text>
          </View>
          <View style={styles.detailRow}>
            <Shield color={colors.textMuted} size={16} />
            <Text style={[styles.detailText, { color: colors.textSecondary }]}>
              {certificate.size} • {certificate.hash.substring(0, 20)}...
            </Text>
          </View>
        </View>

        <View style={styles.certificateActions}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: colors.primary + '20' }]}
            onPress={() => exportToPDF(certificate)}
          >
            <FileText color={colors.primary} size={18} />
            <Text style={[styles.actionText, { color: colors.primary }]}>
              {t.exportPDF}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: colors.secondary + '20' }]}
            onPress={() => exportToJSON(certificate)}
          >
            <Code color={colors.secondary} size={18} />
            <Text style={[styles.actionText, { color: colors.secondary }]}>
              {t.exportJSON}
            </Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    </View>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingHorizontal: 20,
      paddingTop: 20,
      paddingBottom: 30,
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold' as const,
    },
    subtitle: {
      fontSize: 14,
      marginTop: 4,
    },
    certificatesContainer: {
      borderRadius: 20,
      overflow: 'hidden',
    },
    certificatesGradient: {
      padding: 12,
    },
    generateButton: {
      marginHorizontal: 20,
      marginBottom: 20,
      borderRadius: 12,
      overflow: 'hidden',
    },
    generateGradient: {
      padding: 16,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    },
    generateText: {
      fontSize: 16,
      fontWeight: '600' as const,
      marginLeft: 8,
    },
    certificateCard: {
      marginHorizontal: 20,
      marginBottom: 16,
      borderRadius: 12,
      overflow: 'hidden',
      borderWidth: 1,
    },
    certificateGradient: {
      padding: 16,
    },
    certificateHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 12,
    },
    certificateIcon: {
      width: 48,
      height: 48,
      borderRadius: 12,
      backgroundColor: colors.primary + '20',
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
    },
    certificateInfo: {
      flex: 1,
    },
    certificateTitle: {
      fontSize: 16,
      fontWeight: '600' as const,
    },
    certificateSubtitle: {
      fontSize: 12,
      marginTop: 2,
    },
    certificateDetails: {
      marginBottom: 16,
    },
    detailRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 8,
    },
    detailText: {
      fontSize: 14,
      marginLeft: 8,
      flex: 1,
    },
    certificateActions: {
      flexDirection: 'row',
      gap: 12,
    },
    actionButton: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 12,
      paddingHorizontal: 16,
      borderRadius: 8,
    },
    actionText: {
      fontSize: 14,
      fontWeight: '600' as const,
      marginLeft: 6,
    },
    emptyState: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 40,
    },
    emptyIcon: {
      width: 80,
      height: 80,
      borderRadius: 20,
      backgroundColor: colors.surface,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20,
    },
    emptyTitle: {
      fontSize: 20,
      fontWeight: 'bold' as const,
      marginBottom: 8,
      textAlign: 'center' as const,
    },
    emptyDescription: {
      fontSize: 16,
      textAlign: 'center' as const,
      lineHeight: 24,
    },
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>{t.wipeCertificates}</Text>
            <Text style={[styles.subtitle, { color: colors.textMuted }]}>Premium compliance certificates</Text>
          </View>
          <View style={styles.certificatesContainer}>
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              style={styles.certificatesGradient}
            >
              <Award color="#FFFFFF" size={24} />
            </LinearGradient>
          </View>
        </View>

        <TouchableOpacity
          style={styles.generateButton}
          onPress={generateSampleCertificate}
        >
          <LinearGradient
            colors={[colors.primary, colors.primaryVariant]}
            style={styles.generateGradient}
          >
            <Plus color="#FFFFFF" size={20} />
            <Text style={[styles.generateText, { color: '#FFFFFF' }]}>
              Generate Premium Certificate
            </Text>
          </LinearGradient>
        </TouchableOpacity>

        {loading ? (
          <View style={styles.emptyState}>
            <Text style={[styles.emptyTitle, { color: colors.text }]}>
              {t.loading}...
            </Text>
          </View>
        ) : certificates.length === 0 ? (
          <View style={styles.emptyState}>
            <View style={styles.emptyIcon}>
              <Award color={colors.textMuted} size={40} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.text }]}>{t.noCertificates}</Text>
            <Text style={[styles.emptyDescription, { color: colors.textMuted }]}>
              Generate premium certificates after completing secure wipe operations to maintain compliance records and prove data destruction.
            </Text>
          </View>
        ) : (
          certificates.map((certificate) => (
            <CertificateCard key={certificate.id} certificate={certificate} />
          ))
        )}
      </ScrollView>
    </View>
  );
}