import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Stack, useRouter } from "expo-router";
import {
  ArrowLeft,
  HardDrive,
  Pi,
  Folder,
  Image,
  Music,
  Video,
  FileText,
  Archive,
  Trash2,
} from "lucide-react-native";

const { width } = Dimensions.get("window");

interface StorageCategory {
  id: string;
  name: string;
  size: number;
  color: readonly [string, string, ...string[]];
  icon: any;
  files: number;
}

export default function StorageAnalyzerScreen() {
  const [totalStorage] = useState(128 * 1024 * 1024 * 1024); // 128 GB
  const [usedStorage, setUsedStorage] = useState(0);
  const [categories, setCategories] = useState<StorageCategory[]>([]);
  const insets = useSafeAreaInsets();
  const router = useRouter();

  useEffect(() => {
    // Mock storage analysis data
    const mockCategories: StorageCategory[] = [
      {
        id: "photos",
        name: "Photos & Videos",
        size: 45 * 1024 * 1024 * 1024, // 45 GB
        color: ["#EF4444", "#DC2626"],
        icon: Image,
        files: 12847,
      },
      {
        id: "music",
        name: "Music & Audio",
        size: 18 * 1024 * 1024 * 1024, // 18 GB
        color: ["#8B5CF6", "#7C3AED"],
        icon: Music,
        files: 3421,
      },
      {
        id: "videos",
        name: "Videos",
        size: 12 * 1024 * 1024 * 1024, // 12 GB
        color: ["#F59E0B", "#D97706"],
        icon: Video,
        files: 156,
      },
      {
        id: "documents",
        name: "Documents",
        size: 3.2 * 1024 * 1024 * 1024, // 3.2 GB
        color: ["#10B981", "#059669"],
        icon: FileText,
        files: 2847,
      },
      {
        id: "apps",
        name: "Applications",
        size: 8.5 * 1024 * 1024 * 1024, // 8.5 GB
        color: ["#3B82F6", "#2563EB"],
        icon: Archive,
        files: 127,
      },
      {
        id: "other",
        name: "Other Files",
        size: 2.1 * 1024 * 1024 * 1024, // 2.1 GB
        color: ["#6B7280", "#4B5563"],
        icon: Folder,
        files: 1456,
      },
    ];

    setCategories(mockCategories);
    setUsedStorage(mockCategories.reduce((sum, cat) => sum + cat.size, 0));
  }, []);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const getUsagePercentage = (size: number) => {
    return (size / totalStorage) * 100;
  };

  const freeStorage = totalStorage - usedStorage;
  const usagePercentage = (usedStorage / totalStorage) * 100;

  const StorageBar = () => {
    let currentPosition = 0;
    
    return (
      <View style={styles.storageBar}>
        {categories.map((category) => {
          const percentage = getUsagePercentage(category.size);
          const segmentWidth = (percentage / 100) * (width - 40);
          currentPosition += segmentWidth;
          
          return (
            <LinearGradient
              key={category.id}
              colors={category.color}
              style={[styles.storageSegment, { width: segmentWidth }]}
            />
          );
        })}
        <View style={[styles.freeSegment, { flex: 1 }]} />
      </View>
    );
  };

  const CategoryCard = ({ category }: { category: StorageCategory }) => {
    const Icon = category.icon;
    const percentage = getUsagePercentage(category.size);

    return (
      <TouchableOpacity style={styles.categoryCard}>
        <LinearGradient
          colors={["#1E293B", "#334155"]}
          style={styles.categoryGradient}
        >
          <View style={styles.categoryHeader}>
            <View style={styles.categoryIconContainer}>
              <LinearGradient colors={category.color} style={styles.categoryIconGradient}>
                <Icon color="#FFFFFF" size={20} />
              </LinearGradient>
            </View>
            <View style={styles.categoryInfo}>
              <Text style={styles.categoryName}>{category.name}</Text>
              <Text style={styles.categoryFiles}>{category.files.toLocaleString()} files</Text>
            </View>
            <View style={styles.categoryStats}>
              <Text style={styles.categorySize}>{formatBytes(category.size)}</Text>
              <Text style={styles.categoryPercentage}>{percentage.toFixed(1)}%</Text>
            </View>
          </View>
          
          <View style={styles.categoryBarContainer}>
            <View style={styles.categoryBarBackground}>
              <LinearGradient
                colors={category.color}
                style={[styles.categoryBarFill, { width: `${percentage}%` }]}
              />
            </View>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Stack.Screen
        options={{
          headerShown: true,
          headerTitle: "Storage Analyzer",
          headerStyle: { backgroundColor: "#0F172A" },
          headerTintColor: "#FFFFFF",
          headerTitleStyle: { fontWeight: "bold" },
          headerLeft: () => (
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <ArrowLeft color="#FFFFFF" size={24} />
            </TouchableOpacity>
          ),
        }}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Storage Overview */}
        <View style={styles.overviewCard}>
          <LinearGradient
            colors={["#7C3AED", "#3B82F6"]}
            style={styles.overviewGradient}
          >
            <View style={styles.overviewHeader}>
              <HardDrive color="#FFFFFF" size={32} />
              <Text style={styles.overviewTitle}>Storage Overview</Text>
            </View>
            
            <View style={styles.overviewStats}>
              <View style={styles.overviewStat}>
                <Text style={styles.overviewValue}>{formatBytes(usedStorage)}</Text>
                <Text style={styles.overviewLabel}>Used</Text>
              </View>
              <View style={styles.overviewDivider} />
              <View style={styles.overviewStat}>
                <Text style={styles.overviewValue}>{formatBytes(freeStorage)}</Text>
                <Text style={styles.overviewLabel}>Free</Text>
              </View>
              <View style={styles.overviewDivider} />
              <View style={styles.overviewStat}>
                <Text style={styles.overviewValue}>{formatBytes(totalStorage)}</Text>
                <Text style={styles.overviewLabel}>Total</Text>
              </View>
            </View>
            
            <View style={styles.usageContainer}>
              <Text style={styles.usageText}>
                {usagePercentage.toFixed(1)}% Used
              </Text>
            </View>
          </LinearGradient>
        </View>

        {/* Visual Storage Bar */}
        <View style={styles.visualSection}>
          <Text style={styles.sectionTitle}>Storage Breakdown</Text>
          <View style={styles.storageBarContainer}>
            <StorageBar />
            <View style={styles.storageLabels}>
              <Text style={styles.storageLabel}>Used: {formatBytes(usedStorage)}</Text>
              <Text style={styles.storageLabel}>Free: {formatBytes(freeStorage)}</Text>
            </View>
          </View>
        </View>

        {/* Categories */}
        <Text style={styles.sectionTitle}>Storage Categories</Text>
        
        {categories.map((category) => (
          <CategoryCard key={category.id} category={category} />
        ))}

        {/* Quick Actions */}
        <View style={styles.actionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          
          <TouchableOpacity style={styles.actionCard}>
            <LinearGradient
              colors={["#EF4444", "#DC2626"]}
              style={styles.actionGradient}
            >
              <Trash2 color="#FFFFFF" size={24} />
              <View style={styles.actionInfo}>
                <Text style={styles.actionTitle}>Clean Temporary Files</Text>
                <Text style={styles.actionDescription}>
                  Free up space by removing cache and temporary files
                </Text>
              </View>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionCard}>
            <LinearGradient
              colors={["#8B5CF6", "#7C3AED"]}
              style={styles.actionGradient}
            >
              <Pi color="#FFFFFF" size={24} />
              <View style={styles.actionInfo}>
                <Text style={styles.actionTitle}>Analyze Large Files</Text>
                <Text style={styles.actionDescription}>
                  Find and manage files taking up the most space
                </Text>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Storage Tips */}
        <View style={styles.tipsCard}>
          <LinearGradient
            colors={["#1E293B", "#334155"]}
            style={styles.tipsGradient}
          >
            <Text style={styles.tipsTitle}>Storage Tips</Text>
            <Text style={styles.tipsText}>
              • Regularly clean cache and temporary files{"\n"}
              • Move photos and videos to cloud storage{"\n"}
              • Uninstall unused applications{"\n"}
              • Use secure wipe for sensitive data removal
            </Text>
          </LinearGradient>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0F172A",
  },
  backButton: {
    padding: 8,
  },
  overviewCard: {
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 20,
    overflow: "hidden",
  },
  overviewGradient: {
    padding: 24,
  },
  overviewHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  overviewTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginLeft: 12,
  },
  overviewStats: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  overviewStat: {
    flex: 1,
    alignItems: "center",
  },
  overviewValue: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  overviewLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 4,
  },
  overviewDivider: {
    width: 1,
    height: 40,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    marginHorizontal: 16,
  },
  usageContainer: {
    alignItems: "center",
  },
  usageText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  visualSection: {
    paddingHorizontal: 20,
    marginTop: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 16,
  },
  storageBarContainer: {
    marginBottom: 32,
  },
  storageBar: {
    height: 12,
    borderRadius: 6,
    flexDirection: "row",
    overflow: "hidden",
    backgroundColor: "#374151",
    marginBottom: 12,
  },
  storageSegment: {
    height: "100%",
  },
  freeSegment: {
    backgroundColor: "#374151",
  },
  storageLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  storageLabel: {
    fontSize: 12,
    color: "#94A3B8",
  },
  categoryCard: {
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 12,
    overflow: "hidden",
  },
  categoryGradient: {
    padding: 16,
  },
  categoryHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  categoryIconContainer: {
    borderRadius: 10,
    overflow: "hidden",
    marginRight: 12,
  },
  categoryIconGradient: {
    padding: 8,
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  categoryFiles: {
    fontSize: 12,
    color: "#94A3B8",
    marginTop: 2,
  },
  categoryStats: {
    alignItems: "flex-end",
  },
  categorySize: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  categoryPercentage: {
    fontSize: 12,
    color: "#94A3B8",
    marginTop: 2,
  },
  categoryBarContainer: {
    marginTop: 8,
  },
  categoryBarBackground: {
    height: 4,
    backgroundColor: "#374151",
    borderRadius: 2,
    overflow: "hidden",
  },
  categoryBarFill: {
    height: "100%",
    borderRadius: 2,
  },
  actionsSection: {
    paddingHorizontal: 20,
    marginTop: 32,
  },
  actionCard: {
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 12,
  },
  actionGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  actionInfo: {
    marginLeft: 12,
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
    marginBottom: 4,
  },
  actionDescription: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    lineHeight: 16,
  },
  tipsCard: {
    marginHorizontal: 20,
    marginTop: 20,
    marginBottom: 20,
    borderRadius: 12,
    overflow: "hidden",
  },
  tipsGradient: {
    padding: 16,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 12,
  },
  tipsText: {
    fontSize: 14,
    color: "#94A3B8",
    lineHeight: 20,
  },
});