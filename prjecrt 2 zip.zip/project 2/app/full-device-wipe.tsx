import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Platform,
  BackHandler,
  Modal,
  TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Stack, useRouter } from "expo-router";
import {
  Smartphone,
  AlertTriangle,
  Shield,
  CheckCircle,
  Zap,
  Database,
  HardDrive,
  FileX,
  Settings,
  X,
} from "lucide-react-native";
import * as Haptics from "expo-haptics";
import { useWipeStore } from "@/store/wipe-store";

interface WipePhase {
  id: string;
  name: string;
  description: string;
  icon: any;
  estimatedTime: number;
}

export default function FullDeviceWipeScreen() {
  const [progress, setProgress] = useState(0);
  const [currentPhase, setCurrentPhase] = useState<WipePhase | null>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [wipedData, setWipedData] = useState(0);
  const [currentStep, setCurrentStep] = useState("");
  
  const progressAnim = useMemo(() => new Animated.Value(0), []);
  const pulseAnim = useMemo(() => new Animated.Value(1), []);
  const warningAnim = useMemo(() => new Animated.Value(1), []);
  
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { addWipeRecord } = useWipeStore();

  const wipePhases: WipePhase[] = useMemo(() => [
    {
      id: "preparation",
      name: "System Preparation",
      description: "Preparing device for complete data destruction",
      icon: Settings,
      estimatedTime: 30,
    },
    {
      id: "user_data",
      name: "User Data Destruction",
      description: "Wiping personal files, photos, and documents",
      icon: FileX,
      estimatedTime: 180,
    },
    {
      id: "app_data",
      name: "Application Data Wipe",
      description: "Destroying all app data and cached files",
      icon: Database,
      estimatedTime: 120,
    },
    {
      id: "system_data",
      name: "System Data Erasure",
      description: "Wiping system settings and configurations",
      icon: HardDrive,
      estimatedTime: 90,
    },
    {
      id: "free_space",
      name: "Free Space Overwrite",
      description: "Overwriting all free space with random data",
      icon: Shield,
      estimatedTime: 240,
    },
    {
      id: "verification",
      name: "Verification & Finalization",
      description: "Verifying complete data destruction",
      icon: CheckCircle,
      estimatedTime: 60,
    },
  ], []);

  const [showCannotCancelModal, setShowCannotCancelModal] = useState(false);
  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [showSimulationModal, setShowSimulationModal] = useState(false);

  const startWipeProcess = useCallback(async () => {
    const totalSteps = wipePhases.reduce((sum, phase) => sum + phase.estimatedTime, 0);
    let currentProgress = 0;

    for (let phaseIndex = 0; phaseIndex < wipePhases.length; phaseIndex++) {
      const phase = wipePhases[phaseIndex];
      setCurrentPhase(phase);

      const steps = Math.floor(phase.estimatedTime / 10);
      for (let step = 0; step < steps; step++) {
        const stepProgress = (currentProgress + (step / steps) * phase.estimatedTime) / totalSteps * 100;
        setProgress(Math.min(stepProgress, 100));
        
        setCurrentStep(getStepDescription(phase.id, step, steps));
        
        const dataIncrement = Math.random() * 50 * 1024 * 1024;
        setWipedData(prev => prev + dataIncrement);

        Animated.timing(progressAnim, {
          toValue: stepProgress / 100,
          duration: 100,
          useNativeDriver: false,
        }).start();

        if (Platform.OS !== "web" && step % 5 === 0) {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }

        await new Promise(resolve => setTimeout(resolve, 100));
      }

      currentProgress += phase.estimatedTime;

      addWipeRecord({
        name: `${phase.name} - Full Device Wipe`,
        type: "folder",
        size: Math.random() * 1024 * 1024 * 1024,
        algorithm: "DoD 5220.22-M + Gutmann",
        status: "completed",
      });
    }

    setProgress(100);
    setCurrentStep("Device wipe completed successfully!");
    setIsComplete(true);
    
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }

    setTimeout(() => {
      setShowCompletionModal(true);
    }, 2000);
  }, [addWipeRecord, progressAnim, wipePhases]);

  const startAnimations = useCallback(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(warningAnim, {
          toValue: 0.3,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(warningAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [pulseAnim, warningAnim]);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      if (!isComplete) {
        setShowCannotCancelModal(true);
        return true;
      }
      return false;
    });

    startWipeProcess();
    startAnimations();

    return () => backHandler.remove();
  }, [isComplete, startWipeProcess, startAnimations]);



  const getStepDescription = (phaseId: string, step: number, totalSteps: number): string => {
    const stepDescriptions: Record<string, string[]> = {
      preparation: [
        "Initializing secure wipe protocols...",
        "Analyzing device storage structure...",
        "Preparing encryption keys for destruction...",
      ],
      user_data: [
        "Wiping photos and media files...",
        "Destroying document files...",
        "Erasing download history...",
        "Overwriting personal data...",
      ],
      app_data: [
        "Clearing application caches...",
        "Destroying app databases...",
        "Wiping stored credentials...",
        "Erasing app preferences...",
      ],
      system_data: [
        "Wiping system configurations...",
        "Destroying user accounts...",
        "Erasing network settings...",
        "Overwriting system logs...",
      ],
      free_space: [
        "Pass 1: Writing zeros to free space...",
        "Pass 2: Writing ones to free space...",
        "Pass 3: Random data overwrite...",
        "Gutmann pattern application...",
      ],
      verification: [
        "Verifying data destruction...",
        "Checking for data remnants...",
        "Finalizing wipe process...",
        "Generating completion certificate...",
      ],
    };

    const descriptions = stepDescriptions[phaseId] || ["Processing..."];
    const descriptionIndex = Math.floor((step / totalSteps) * descriptions.length);
    return descriptions[Math.min(descriptionIndex, descriptions.length - 1)];
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const estimatedTimeRemaining = () => {
    if (!currentPhase) return 0;
    const currentPhaseIndex = wipePhases.findIndex(p => p.id === currentPhase.id);
    const remainingPhases = wipePhases.slice(currentPhaseIndex);
    return remainingPhases.reduce((sum, phase) => sum + phase.estimatedTime, 0);
  };

  const CannotCancelModal = () => (
    <Modal
      visible={showCannotCancelModal}
      transparent
      animationType="fade"
      onRequestClose={() => setShowCannotCancelModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <AlertTriangle color="#DC2626" size={32} />
            <Text style={styles.modalTitle}>Cannot Cancel</Text>
            <TouchableOpacity onPress={() => setShowCannotCancelModal(false)} style={styles.closeButton}>
              <X color="#94A3B8" size={24} />
            </TouchableOpacity>
          </View>
          <Text style={styles.modalText}>
            Device wipe is in progress and cannot be interrupted. Please wait for completion.
          </Text>
          <TouchableOpacity
            onPress={() => setShowCannotCancelModal(false)}
            style={styles.modalButton}
          >
            <Text style={styles.modalButtonText}>OK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  const CompletionModal = () => (
    <Modal
      visible={showCompletionModal}
      transparent
      animationType="fade"
      onRequestClose={() => {}}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <CheckCircle color="#10B981" size={32} />
            <Text style={styles.modalTitle}>🔒 Device Wipe Complete</Text>
          </View>
          <Text style={styles.modalText}>
            Your device has been completely wiped using military-grade algorithms. All data has been permanently destroyed and cannot be recovered.
            {"\n\n"}The device will now restart to complete the process.
          </Text>
          <TouchableOpacity
            onPress={() => {
              setShowCompletionModal(false);
              setShowSimulationModal(true);
            }}
            style={[styles.modalButton, { backgroundColor: "#10B981" }]}
          >
            <Text style={styles.modalButtonText}>Restart Device</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  const SimulationModal = () => (
    <Modal
      visible={showSimulationModal}
      transparent
      animationType="fade"
      onRequestClose={() => {}}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Shield color="#8B5CF6" size={32} />
            <Text style={styles.modalTitle}>Simulation Complete</Text>
          </View>
          <Text style={styles.modalText}>
            In a real implementation, the device would restart now. Returning to home screen.
          </Text>
          <TouchableOpacity
            onPress={() => {
              setShowSimulationModal(false);
              router.replace("/home");
            }}
            style={[styles.modalButton, { backgroundColor: "#8B5CF6" }]}
          >
            <Text style={styles.modalButtonText}>OK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <Stack.Screen
        options={{
          headerShown: true,
          headerTitle: "Full Device Wipe",
          headerStyle: { backgroundColor: "#7F1D1D" },
          headerTintColor: "#FFFFFF",
          headerTitleStyle: { fontWeight: "bold" },
          headerBackVisible: false,
          headerLeft: () => null,
        }}
      />
      
      <CannotCancelModal />
      <CompletionModal />
      <SimulationModal />

      <View style={styles.content}>
        {/* Warning Banner */}
        {!isComplete && (
          <Animated.View style={[styles.warningBanner, { opacity: warningAnim }]}>
            <LinearGradient
              colors={["#DC2626", "#B91C1C"]}
              style={styles.warningGradient}
            >
              <AlertTriangle color="#FFFFFF" size={24} />
              <Text style={styles.warningText}>
                CRITICAL: Device wipe in progress - DO NOT power off!
              </Text>
            </LinearGradient>
          </Animated.View>
        )}

        {/* Main Progress Circle */}
        <View style={styles.progressContainer}>
          <Animated.View
            style={[
              styles.progressCircle,
              {
                transform: [{ scale: pulseAnim }],
              },
            ]}
          >
            <LinearGradient
              colors={isComplete ? ["#10B981", "#059669"] : ["#DC2626", "#B91C1C"]}
              style={styles.progressGradient}
            >
              {isComplete ? (
                <CheckCircle color="#FFFFFF" size={48} />
              ) : (
                <Smartphone color="#FFFFFF" size={48} />
              )}
            </LinearGradient>
          </Animated.View>
          
          {/* Progress Ring */}
          <View style={styles.progressRing}>
            <Animated.View
              style={[
                styles.progressFill,
                {
                  transform: [
                    {
                      rotate: progressAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ["0deg", "360deg"],
                      }),
                    },
                  ],
                },
              ]}
            />
          </View>
        </View>

        {/* Progress Text */}
        <Text style={styles.progressText}>{Math.round(progress)}%</Text>
        <Text style={styles.phaseText}>
          {currentPhase ? currentPhase.name : "Initializing..."}
        </Text>

        {/* Current Step */}
        {currentStep && !isComplete && (
          <View style={styles.currentStepCard}>
            <LinearGradient
              colors={["#1E293B", "#334155"]}
              style={styles.currentStepGradient}
            >
              <Zap color="#F59E0B" size={20} />
              <View style={styles.currentStepInfo}>
                <Text style={styles.currentStepLabel}>Current Operation</Text>
                <Text style={styles.currentStepText}>{currentStep}</Text>
              </View>
            </LinearGradient>
          </View>
        )}

        {/* Statistics */}
        <View style={styles.statsCard}>
          <LinearGradient
            colors={["#DC2626", "#B91C1C"]}
            style={styles.statsGradient}
          >
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{formatBytes(wipedData)}</Text>
                <Text style={styles.statLabel}>Data Wiped</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>
                  {isComplete ? "00:00" : formatTime(estimatedTimeRemaining())}
                </Text>
                <Text style={styles.statLabel}>Time Remaining</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>
                  {currentPhase ? wipePhases.findIndex(p => p.id === currentPhase.id) + 1 : 0}/6
                </Text>
                <Text style={styles.statLabel}>Phase</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* Algorithm Info */}
        <View style={styles.algorithmCard}>
          <LinearGradient
            colors={["#1E293B", "#334155"]}
            style={styles.algorithmGradient}
          >
            <Shield color="#8B5CF6" size={20} />
            <View style={styles.algorithmInfo}>
              <Text style={styles.algorithmTitle}>DoD 5220.22-M + Gutmann Method</Text>
              <Text style={styles.algorithmDescription}>
                Military-grade 35-pass overwrite for maximum security
              </Text>
            </View>
          </LinearGradient>
        </View>

        {/* Phase Progress */}
        {currentPhase && !isComplete && (
          <View style={styles.phaseCard}>
            <LinearGradient
              colors={["#1E293B", "#334155"]}
              style={styles.phaseGradient}
            >
              <View style={styles.phaseHeader}>
                <currentPhase.icon color="#DC2626" size={24} />
                <View style={styles.phaseInfo}>
                  <Text style={styles.phaseTitle}>{currentPhase.name}</Text>
                  <Text style={styles.phaseDescription}>{currentPhase.description}</Text>
                </View>
              </View>
            </LinearGradient>
          </View>
        )}

        {/* Completion Message */}
        {isComplete && (
          <View style={styles.completionMessage}>
            <LinearGradient
              colors={["#10B981", "#059669"]}
              style={styles.completionGradient}
            >
              <CheckCircle color="#FFFFFF" size={24} />
              <View style={styles.completionText}>
                <Text style={styles.completionTitle}>Device Wipe Complete</Text>
                <Text style={styles.completionDescription}>
                  All data has been permanently destroyed using military-grade algorithms. 
                  Your device is now completely secure.
                </Text>
              </View>
            </LinearGradient>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0F172A",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.8)",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  modalContent: {
    backgroundColor: "#1E293B",
    borderRadius: 16,
    padding: 24,
    width: "100%",
    maxWidth: 400,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold" as const,
    color: "#FFFFFF",
    flex: 1,
    marginLeft: 12,
  },
  closeButton: {
    padding: 4,
  },
  modalText: {
    fontSize: 16,
    color: "#E2E8F0",
    lineHeight: 24,
    marginBottom: 20,
  },
  modalButton: {
    backgroundColor: "#DC2626",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    alignItems: "center",
  },
  modalButtonText: {
    fontSize: 16,
    fontWeight: "600" as const,
    color: "#FFFFFF",
  },
  content: {
    flex: 1,
    padding: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  warningBanner: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 20,
  },
  warningGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  warningText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginLeft: 12,
    flex: 1,
  },
  progressContainer: {
    position: "relative",
    marginBottom: 32,
  },
  progressCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    overflow: "hidden",
  },
  progressGradient: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  progressRing: {
    position: "absolute",
    top: -10,
    left: -10,
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 4,
    borderColor: "rgba(220, 38, 38, 0.2)",
  },
  progressFill: {
    position: "absolute",
    top: -2,
    left: -2,
    width: 4,
    height: 72,
    backgroundColor: "#DC2626",
    borderRadius: 2,
    transformOrigin: "2px 72px",
  },
  progressText: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  phaseText: {
    fontSize: 16,
    color: "#94A3B8",
    textAlign: "center",
    marginBottom: 32,
  },
  currentStepCard: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 24,
  },
  currentStepGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  currentStepInfo: {
    marginLeft: 12,
    flex: 1,
  },
  currentStepLabel: {
    fontSize: 12,
    color: "#94A3B8",
    marginBottom: 2,
  },
  currentStepText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  statsCard: {
    width: "100%",
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 24,
  },
  statsGradient: {
    padding: 20,
  },
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
  },
  statValue: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  statLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.8)",
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    marginHorizontal: 16,
  },
  algorithmCard: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 24,
  },
  algorithmGradient: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  algorithmInfo: {
    marginLeft: 12,
    flex: 1,
  },
  algorithmTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
    marginBottom: 2,
  },
  algorithmDescription: {
    fontSize: 12,
    color: "#94A3B8",
  },
  phaseCard: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 24,
  },
  phaseGradient: {
    padding: 16,
  },
  phaseHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  phaseInfo: {
    marginLeft: 12,
    flex: 1,
  },
  phaseTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
    marginBottom: 2,
  },
  phaseDescription: {
    fontSize: 12,
    color: "#94A3B8",
  },
  completionMessage: {
    width: "100%",
    borderRadius: 16,
    overflow: "hidden",
  },
  completionGradient: {
    padding: 20,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  completionText: {
    marginLeft: 12,
    flex: 1,
  },
  completionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 4,
  },
  completionDescription: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 20,
  },
});