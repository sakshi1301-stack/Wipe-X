import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { StatusBar } from "expo-status-bar";
import { StyleSheet } from "react-native";
import { AuthProvider } from "@/store/auth-store";
import { ThemeProvider } from "@/store/theme-context";
import { useSettingsStore } from "@/store/settings-store";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  const { loadSettings } = useSettingsStore();

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  return (
    <ThemeProvider>
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerBackTitle: "Back" }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="auth" options={{ headerShown: false }} />
        <Stack.Screen 
          name="file-selector" 
          options={{ 
            headerShown: false,
            presentation: "modal",
          }} 
        />
        <Stack.Screen 
          name="wipe-progress" 
          options={{ 
            headerShown: false,
            presentation: "fullScreenModal",
          }} 
        />
        <Stack.Screen 
          name="full-device-wipe" 
          options={{ 
            headerShown: false,
            presentation: "fullScreenModal",
            gestureEnabled: false,
          }} 
        />
        <Stack.Screen 
          name="storage-analyzer" 
          options={{ 
            headerShown: false,
            presentation: "modal",
          }} 
        />
        <Stack.Screen 
          name="modal" 
          options={{ 
            presentation: "modal",
            headerShown: false,
          }} 
        />
      </Stack>
    </ThemeProvider>
  );
}

export default function RootLayout() {
  useEffect(() => {
    SplashScreen.hideAsync();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <GestureHandlerRootView style={styles.container}>
          <RootLayoutNav />
        </GestureHandlerRootView>
      </AuthProvider>
    </QueryClientProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});