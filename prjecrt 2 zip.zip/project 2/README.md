# SecureWipe - Military-Grade File Deletion App

A comprehensive React Native application for secure file deletion, built with Expo and featuring military-grade wiping algorithms, biometric authentication, and real-time progress tracking.

## 🚀 Features

### Core Functionality
- **Secure File Wiping**: Select individual files, folders, or storage sections for permanent deletion
- **Multiple Wipe Algorithms**: 
  - Fast Wipe (Single pass)
  - DoD 5220.22-M (3-pass military standard)
  - Gutmann (35-pass maximum security)
  - Random Overwrite (7-pass random data)
- **Free Space Erasing**: Erase unused/free space to prevent recovery of deleted files
- **Quick Wipe**: One-tap option to wipe recent files/cache securely
- **Real-time Progress**: Live progress tracking with detailed phase information

### Security Features
- **Biometric Authentication**: Fingerprint and PIN protection
- **Military-Grade Encryption**: DoD 5220.22-M standard implementation
- **Local Processing**: All operations performed locally for maximum privacy
- **Secure Storage**: Encrypted storage of sensitive app data

### User Experience
- **Modern UI/UX**: Clean, minimal, futuristic design with smooth animations
- **Dark Theme**: Battery-efficient dark mode with neon gradient accents
- **Haptic Feedback**: Tactile feedback for better user interaction
- **Multi-language Support**: English, Spanish, French, German
- **Storage Analytics**: Detailed storage breakdown and usage statistics

### Reports & Logging
- **Wipe History**: Complete history of deleted/wiped files with timestamps
- **Exportable Logs**: Generate detailed reports of all wipe operations
- **Statistics Dashboard**: Track total wipes and data secured

## 🛠 Tech Stack

- **Framework**: React Native with Expo SDK 53
- **Language**: TypeScript for type safety
- **State Management**: Zustand + @nkzw/create-context-hook
- **Navigation**: Expo Router (file-based routing)
- **UI Components**: Custom components with LinearGradient
- **Icons**: Lucide React Native
- **Storage**: AsyncStorage for local data persistence
- **Animations**: React Native Animated API
- **Haptics**: Expo Haptics for tactile feedback

## 📱 Screen Structure

```
app/
├── _layout.tsx                 # Root layout with providers
├── (tabs)/                     # Tab navigation
│   ├── _layout.tsx            # Tab layout configuration
│   ├── index.tsx              # Home dashboard
│   ├── quick-wipe.tsx         # Quick wipe actions
│   ├── history.tsx            # Wipe history and logs
│   └── settings.tsx           # App settings and preferences
├── auth.tsx                   # Authentication screen
├── file-selector.tsx          # File/folder selection
├── wipe-progress.tsx          # Real-time wipe progress
└── storage-analyzer.tsx       # Storage analysis and breakdown
```

## 🎨 Design System

### Color Palette
- **Primary**: Purple/Blue gradients (#8B5CF6, #3B82F6)
- **Background**: Dark slate (#0F172A, #1E293B)
- **Accent Colors**:
  - Success: Green (#10B981)
  - Warning: Orange (#F59E0B)
  - Danger: Red (#EF4444)
  - Info: Blue (#3B82F6)

### Typography
- **Headers**: Bold, 28px
- **Body**: Regular, 16px
- **Captions**: 12px with reduced opacity

### Components
- **Cards**: Rounded corners (12-20px) with gradient backgrounds
- **Buttons**: Gradient fills with haptic feedback
- **Progress Indicators**: Animated circular and linear progress bars
- **Icons**: Lucide icons with consistent sizing (20-32px)

## 🔧 Installation & Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd securewipe-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Start the development server**
   ```bash
   npx expo start
   ```

4. **Run on device/simulator**
   - Scan QR code with Expo Go app (mobile)
   - Press 'i' for iOS simulator
   - Press 'a' for Android emulator
   - Press 'w' for web browser

## 📋 Usage Guide

### Getting Started
1. **Authentication**: Set up PIN or biometric authentication in Settings
2. **File Selection**: Use \"Wipe Files\" to select specific files/folders
3. **Quick Actions**: Use Quick Wipe for common cleanup tasks
4. **Monitor Progress**: Track wipe operations in real-time
5. **Review History**: Check completed operations in History tab

### Wipe Algorithms
- **Fast Wipe**: Best for non-sensitive data, single pass overwrite
- **DoD 5220.22-M**: Military standard, 3-pass overwrite (recommended)
- **Gutmann**: Maximum security, 35-pass overwrite (slower)
- **Random**: Balanced security, 7-pass random data overwrite

### Security Best Practices
- Enable authentication for app access
- Use DoD 5220.22-M or higher for sensitive data
- Regularly clean temporary files and cache
- Verify wipe completion in History tab

## 🔒 Security Implementation

### Wipe Algorithms
The app implements industry-standard secure deletion algorithms:

1. **DoD 5220.22-M Standard**:
   - Pass 1: Write binary zeros (0x00)
   - Pass 2: Write binary ones (0xFF)
   - Pass 3: Write random data
   - Verification pass to ensure completion

2. **Gutmann Method**:
   - 35 passes with specific patterns
   - Designed to defeat magnetic force microscopy
   - Maximum security for highly sensitive data

### Authentication
- Biometric authentication using device capabilities
- PIN-based fallback with attempt limiting
- Session timeout for automatic logout
- Secure storage of authentication tokens

### Privacy Protection
- All operations performed locally on device
- No data transmission to external servers
- Encrypted storage of app preferences
- Complete user data control

## 🚀 Performance Optimizations

- **Lazy Loading**: Screens loaded on demand
- **Memoization**: React.memo() and useMemo() for expensive operations
- **Efficient Rendering**: Optimized list rendering for large file sets
- **Background Processing**: Non-blocking wipe operations
- **Memory Management**: Proper cleanup of resources

## 🧪 Testing

The app includes comprehensive testing for:
- File selection and validation
- Wipe algorithm implementation
- Authentication flows
- Storage calculations
- Error handling and recovery

## 📦 Build & Deployment

### Development Build
```bash
npx expo build:android
npx expo build:ios
```

### Production Build
```bash
eas build --platform android
eas build --platform ios
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🛡 Security Disclaimer

This application is designed for educational and legitimate data protection purposes. Users are responsible for complying with local laws and regulations regarding data deletion and privacy. The developers are not responsible for any misuse of this software.

## 📞 Support

For support, feature requests, or bug reports, please open an issue on the GitHub repository.

---

**SecureWipe** - Your data protection companion 🛡️