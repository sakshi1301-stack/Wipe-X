import { create } from "zustand";
import { combine } from "zustand/middleware";
import AsyncStorage from '@react-native-async-storage/async-storage';

export type Language = "en" | "es" | "hi";
export type Theme = "light" | "dark" | "auto";

export const useSettingsStore = create(
  combine(
    {
      theme: "dark" as Theme,
      wipeAlgorithm: "dod" as "fast" | "dod" | "gutmann" | "random",
      requireAuth: false,
      language: "en" as Language,
    },
    (set, get) => ({
      setTheme: async (theme: Theme) => {
        set({ theme });
        await AsyncStorage.setItem('theme', theme);
      },
        
      setWipeAlgorithm: async (algorithm: "fast" | "dod" | "gutmann" | "random") => {
        set({ wipeAlgorithm: algorithm });
        await AsyncStorage.setItem('wipeAlgorithm', algorithm);
      },
        
      toggleAuth: async () => {
        const newValue = !get().requireAuth;
        set({ requireAuth: newValue });
        await AsyncStorage.setItem('requireAuth', JSON.stringify(newValue));
      },
        
      setLanguage: async (language: Language) => {
        set({ language });
        await AsyncStorage.setItem('language', language);
      },



      loadSettings: async () => {
        try {
          const [theme, wipeAlgorithm, requireAuth, language] = await Promise.all([
            AsyncStorage.getItem('theme'),
            AsyncStorage.getItem('wipeAlgorithm'),
            AsyncStorage.getItem('requireAuth'),
            AsyncStorage.getItem('language'),
          ]);

          set({
            theme: (theme as Theme) || 'dark',
            wipeAlgorithm: (wipeAlgorithm as any) || 'dod',
            requireAuth: requireAuth ? JSON.parse(requireAuth) : false,
            language: (language as Language) || 'en',
          });
        } catch (error) {
          console.log('Error loading settings:', error);
        }
      },
    })
  )
);