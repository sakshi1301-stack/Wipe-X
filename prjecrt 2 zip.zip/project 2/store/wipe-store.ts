import { create } from "zustand";
import { combine } from "zustand/middleware";

interface WipeHistoryItem {
  id: string;
  name: string;
  type: "file" | "folder" | "cache" | "free-space";
  size: number;
  algorithm: string;
  date: Date;
  status: "completed" | "failed";
}

export const useWipeStore = create(
  combine(
    {
      totalWipes: 47,
      totalDataWiped: 12847362048, // ~12 GB in bytes
      wipeHistory: [
        {
          id: "1",
          name: "Downloads/document.pdf",
          type: "file" as const,
          size: 2048576, // 2 MB
          algorithm: "DoD 5220.22-M",
          date: new Date(Date.now() - 3600000), // 1 hour ago
          status: "completed" as const,
        },
        {
          id: "2",
          name: "Temporary Files",
          type: "cache" as const,
          size: 52428800, // 50 MB
          algorithm: "Fast Wipe",
          date: new Date(Date.now() - 7200000), // 2 hours ago
          status: "completed" as const,
        },
        {
          id: "3",
          name: "Pictures/vacation",
          type: "folder" as const,
          size: 104857600, // 100 MB
          algorithm: "Gutmann",
          date: new Date(Date.now() - 86400000), // 1 day ago
          status: "completed" as const,
        },
      ] as WipeHistoryItem[],
    },
    (set) => ({
      addWipeRecord: (record: Omit<WipeHistoryItem, "id" | "date">) =>
        set((state) => ({
          totalWipes: state.totalWipes + 1,
          totalDataWiped: state.totalDataWiped + record.size,
          wipeHistory: [
            {
              ...record,
              id: Date.now().toString(),
              date: new Date(),
            },
            ...state.wipeHistory,
          ].slice(0, 50), // Keep only last 50 records
        })),
        
      clearHistory: () =>
        set((state) => ({
          wipeHistory: [],
        })),
    })
  )
);