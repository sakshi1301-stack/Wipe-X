import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import { Platform } from 'react-native';

export interface StorageInfo {
  totalSpace: number;
  freeSpace: number;
  usedSpace: number;
}

export interface FileInfo {
  id: string;
  name: string;
  uri: string;
  size: number;
  type: 'file' | 'folder';
  mimeType?: string;
  modificationTime: number;
}

export interface StorageCategory {
  id: string;
  name: string;
  size: number;
  files: FileInfo[];
  color: readonly [string, string, ...string[]];
}

class StorageService {
  async getStorageInfo(): Promise<StorageInfo> {
    try {
      if (Platform.OS === 'web') {
        // Web fallback with estimated values
        return {
          totalSpace: 128 * 1024 * 1024 * 1024, // 128 GB
          freeSpace: 42 * 1024 * 1024 * 1024,   // 42 GB
          usedSpace: 86 * 1024 * 1024 * 1024,   // 86 GB
        };
      }

      const info = await FileSystem.getFreeDiskStorageAsync();
      const totalSpace = await FileSystem.getTotalDiskCapacityAsync();
      
      return {
        totalSpace: totalSpace || 128 * 1024 * 1024 * 1024,
        freeSpace: info || 42 * 1024 * 1024 * 1024,
        usedSpace: (totalSpace || 128 * 1024 * 1024 * 1024) - (info || 42 * 1024 * 1024 * 1024),
      };
    } catch (error) {
      console.log('Storage info error:', error);
      // Fallback values
      return {
        totalSpace: 128 * 1024 * 1024 * 1024,
        freeSpace: 42 * 1024 * 1024 * 1024,
        usedSpace: 86 * 1024 * 1024 * 1024,
      };
    }
  }

  async getMediaFiles(): Promise<FileInfo[]> {
    try {
      if (Platform.OS === 'web') {
        return this.getMockFiles();
      }

      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        console.log('Media library permission denied');
        return this.getMockFiles();
      }

      const assets = await MediaLibrary.getAssetsAsync({
        first: 1000,
        mediaType: [MediaLibrary.MediaType.photo, MediaLibrary.MediaType.video],
      });

      return assets.assets.map((asset, index) => ({
        id: asset.id || index.toString(),
        name: asset.filename,
        uri: asset.uri,
        size: asset.width * asset.height * 3, // Estimated size
        type: 'file' as const,
        mimeType: asset.mediaType === MediaLibrary.MediaType.photo ? 'image/jpeg' : 'video/mp4',
        modificationTime: asset.modificationTime || Date.now(),
      }));
    } catch (error) {
      console.log('Media files error:', error);
      return this.getMockFiles();
    }
  }

  async getDocumentFiles(): Promise<FileInfo[]> {
    try {
      if (Platform.OS === 'web') {
        return this.getMockDocuments();
      }

      const documentsDir = FileSystem.documentDirectory;
      if (!documentsDir) {
        return this.getMockDocuments();
      }

      const files = await FileSystem.readDirectoryAsync(documentsDir);
      const fileInfos: FileInfo[] = [];

      for (const fileName of files) {
        try {
          const fileUri = documentsDir + fileName;
          const info = await FileSystem.getInfoAsync(fileUri);
          
          if (info.exists) {
            fileInfos.push({
              id: fileName,
              name: fileName,
              uri: fileUri,
              size: info.size || 0,
              type: info.isDirectory ? 'folder' : 'file',
              modificationTime: info.modificationTime || Date.now(),
            });
          }
        } catch (fileError) {
          console.log(`Error reading file ${fileName}:`, fileError);
        }
      }

      return fileInfos;
    } catch (error) {
      console.log('Document files error:', error);
      return this.getMockDocuments();
    }
  }

  async getCacheSize(): Promise<number> {
    try {
      if (Platform.OS === 'web') {
        return 250 * 1024 * 1024; // 250 MB mock
      }

      const cacheDir = FileSystem.cacheDirectory;
      if (!cacheDir) {
        return 250 * 1024 * 1024;
      }

      const files = await FileSystem.readDirectoryAsync(cacheDir);
      let totalSize = 0;

      for (const fileName of files) {
        try {
          const fileUri = cacheDir + fileName;
          const info = await FileSystem.getInfoAsync(fileUri);
          if (info.exists && info.size) {
            totalSize += info.size;
          }
        } catch (fileError) {
          console.log(`Error reading cache file ${fileName}:`, fileError);
        }
      }

      return totalSize;
    } catch (error) {
      console.log('Cache size error:', error);
      return 250 * 1024 * 1024;
    }
  }

  async getStorageCategories(): Promise<StorageCategory[]> {
    try {
      const [mediaFiles, documentFiles, cacheSize] = await Promise.all([
        this.getMediaFiles(),
        this.getDocumentFiles(),
        this.getCacheSize(),
      ]);

      const photoFiles = mediaFiles.filter(f => f.mimeType?.startsWith('image/'));
      const videoFiles = mediaFiles.filter(f => f.mimeType?.startsWith('video/'));
      
      return [
        {
          id: 'photos',
          name: 'Photos',
          size: photoFiles.reduce((sum, f) => sum + f.size, 0),
          files: photoFiles,
          color: ['#00FF88', '#00CC6A'] as const,
        },
        {
          id: 'videos',
          name: 'Videos',
          size: videoFiles.reduce((sum, f) => sum + f.size, 0),
          files: videoFiles,
          color: ['#FF6B6B', '#FF5252'] as const,
        },
        {
          id: 'documents',
          name: 'Documents',
          size: documentFiles.reduce((sum, f) => sum + f.size, 0),
          files: documentFiles,
          color: ['#4ECDC4', '#26A69A'] as const,
        },
        {
          id: 'cache',
          name: 'Cache & Temp',
          size: cacheSize,
          files: [],
          color: ['#FFD93D', '#FFC107'] as const,
        },
      ];
    } catch (error) {
      console.log('Storage categories error:', error);
      return this.getMockCategories();
    }
  }

  async deleteFile(fileUri: string): Promise<boolean> {
    try {
      if (Platform.OS === 'web') {
        console.log('File deletion simulated on web:', fileUri);
        return true;
      }

      await FileSystem.deleteAsync(fileUri, { idempotent: true });
      return true;
    } catch (error) {
      console.log('Delete file error:', error);
      return false;
    }
  }

  async clearCache(): Promise<boolean> {
    try {
      if (Platform.OS === 'web') {
        console.log('Cache clearing simulated on web');
        return true;
      }

      const cacheDir = FileSystem.cacheDirectory;
      if (!cacheDir) {
        return false;
      }

      const files = await FileSystem.readDirectoryAsync(cacheDir);
      
      for (const fileName of files) {
        try {
          const fileUri = cacheDir + fileName;
          await FileSystem.deleteAsync(fileUri, { idempotent: true });
        } catch (fileError) {
          console.log(`Error deleting cache file ${fileName}:`, fileError);
        }
      }

      return true;
    } catch (error) {
      console.log('Clear cache error:', error);
      return false;
    }
  }

  private getMockFiles(): FileInfo[] {
    return [
      {
        id: '1',
        name: 'vacation_photo_1.jpg',
        uri: 'mock://photo1.jpg',
        size: 2.5 * 1024 * 1024,
        type: 'file',
        mimeType: 'image/jpeg',
        modificationTime: Date.now() - 86400000,
      },
      {
        id: '2',
        name: 'family_video.mp4',
        uri: 'mock://video1.mp4',
        size: 45 * 1024 * 1024,
        type: 'file',
        mimeType: 'video/mp4',
        modificationTime: Date.now() - 172800000,
      },
    ];
  }

  private getMockDocuments(): FileInfo[] {
    return [
      {
        id: '3',
        name: 'important_document.pdf',
        uri: 'mock://doc1.pdf',
        size: 1.2 * 1024 * 1024,
        type: 'file',
        mimeType: 'application/pdf',
        modificationTime: Date.now() - 259200000,
      },
    ];
  }

  private getMockCategories(): StorageCategory[] {
    return [
      {
        id: 'photos',
        name: 'Photos',
        size: 15 * 1024 * 1024 * 1024,
        files: this.getMockFiles().filter(f => f.mimeType?.startsWith('image/')),
        color: ['#00FF88', '#00CC6A'] as const,
      },
      {
        id: 'videos',
        name: 'Videos',
        size: 25 * 1024 * 1024 * 1024,
        files: this.getMockFiles().filter(f => f.mimeType?.startsWith('video/')),
        color: ['#FF6B6B', '#FF5252'] as const,
      },
      {
        id: 'documents',
        name: 'Documents',
        size: 2 * 1024 * 1024 * 1024,
        files: this.getMockDocuments(),
        color: ['#4ECDC4', '#26A69A'] as const,
      },
      {
        id: 'cache',
        name: 'Cache & Temp',
        size: 250 * 1024 * 1024,
        files: [],
        color: ['#FFD93D', '#FFC107'] as const,
      },
    ];
  }
}

export const storageService = new StorageService();