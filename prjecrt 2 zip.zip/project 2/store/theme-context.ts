import createContextHook from '@nkzw/create-context-hook';
import { useColorScheme } from 'react-native';
import { useSettingsStore, Theme } from './settings-store';
import { useMemo } from 'react';

export interface ThemeColors {
  background: string;
  surface: string;
  surfaceVariant: string;
  primary: string;
  primaryVariant: string;
  secondary: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  border: string;
  success: string;
  warning: string;
  error: string;
  accent: string;
  accentVariant: string;
  card: string;
  cardVariant: string;
  tabBar: string;
  tabBarActive: string;
  tabBarInactive: string;
}

const lightTheme: ThemeColors = {
  background: '#FAFBFC',
  surface: '#FFFFFF',
  surfaceVariant: '#F7F9FC',
  primary: '#6366F1',
  primaryVariant: '#4F46E5',
  secondary: '#14B8A6',
  text: '#0F172A',
  textSecondary: '#334155',
  textMuted: '#64748B',
  border: '#E2E8F0',
  success: '#059669',
  warning: '#D97706',
  error: '#DC2626',
  accent: '#8B5CF6',
  accentVariant: '#7C3AED',
  card: '#FFFFFF',
  cardVariant: '#F8FAFC',
  tabBar: '#FFFFFF',
  tabBarActive: '#6366F1',
  tabBarInactive: '#64748B',
};

const darkTheme: ThemeColors = {
  background: '#0A0B0F',
  surface: '#1A1B23',
  surfaceVariant: '#252631',
  primary: '#8B5CF6',
  primaryVariant: '#7C3AED',
  secondary: '#06B6D4',
  text: '#F8FAFC',
  textSecondary: '#E2E8F0',
  textMuted: '#94A3B8',
  border: '#2D3748',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  accent: '#A855F7',
  accentVariant: '#9333EA',
  card: '#1A1B23',
  cardVariant: '#252631',
  tabBar: '#0A0B0F',
  tabBarActive: '#8B5CF6',
  tabBarInactive: '#64748B',
};



export const [ThemeProvider, useTheme] = createContextHook(() => {
  const { theme } = useSettingsStore();
  const systemColorScheme = useColorScheme();

  const currentTheme = useMemo(() => {
    let selectedTheme: 'light' | 'dark';
    
    if (theme === 'auto') {
      selectedTheme = systemColorScheme === 'dark' ? 'dark' : 'light';
    } else {
      selectedTheme = theme;
    }

    return selectedTheme === 'dark' ? darkTheme : lightTheme;
  }, [theme, systemColorScheme]);

  const isDark = useMemo(() => {
    if (theme === 'auto') {
      return systemColorScheme === 'dark';
    }
    return theme === 'dark';
  }, [theme, systemColorScheme]);

  return {
    colors: currentTheme,
    isDark,
    theme,
  };
});