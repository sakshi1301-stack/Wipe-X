import { Language } from '@/store/settings-store';

export interface Translations {
  // Navigation
  home: string;
  history: string;
  settings: string;
  certificates: string;

  // Home Screen
  totalStorage: string;
  freeSpace: string;
  usedSpace: string;
  selectFiles: string;
  selectFolders: string;
  eraseSpace: string;
  startWipe: string;
  storageAnalysis: string;
  secureWipe: string;
  militaryGrade: string;
  dataProtection: string;

  // Settings
  security: string;
  appearance: string;
  general: string;
  performance: string;
  wipeAlgorithm: string;
  requireAuthentication: string;
  protectApp: string;
  theme: string;
  darkMode: string;
  lightMode: string;
  autoMode: string;
  colorCorrection: string;
  language: string;
  about: string;
  version: string;
  privacyFirst: string;
  localOperations: string;

  // Wipe Algorithms
  fastWipe: string;
  dodStandard: string;
  gutmannMethod: string;
  randomOverwrite: string;
  singlePass: string;
  threePassMilitary: string;
  thirtyFivePass: string;
  sevenPassRandom: string;

  // History
  wipeHistory: string;
  noHistory: string;
  filesWiped: string;
  completedAt: string;
  algorithm: string;
  size: string;

  // Certificates
  wipeCertificates: string;
  noCertificates: string;
  generateCertificate: string;
  exportPDF: string;
  exportJSON: string;
  certificateGenerated: string;
  dataWipedSecurely: string;
  certificationDetails: string;

  // Common
  cancel: string;
  confirm: string;
  delete: string;
  export: string;
  success: string;
  error: string;
  warning: string;
  loading: string;
  complete: string;
  progress: string;
}

const translations: Record<Language, Translations> = {
  en: {
    // Navigation
    home: 'Home',
    history: 'History',
    settings: 'Settings',
    certificates: 'Certificates',

    // Home Screen
    totalStorage: 'Total Storage',
    freeSpace: 'Free Space',
    usedSpace: 'Used Space',
    selectFiles: 'Select Files',
    selectFolders: 'Select Folders',
    eraseSpace: 'Erase Free Space',
    startWipe: 'Start Secure Wipe',
    storageAnalysis: 'Storage Analysis',
    secureWipe: 'WipeX',
    militaryGrade: 'Military-grade secure file deletion',
    dataProtection: 'Complete data protection',

    // Settings
    security: 'Security',
    appearance: 'Appearance',
    general: 'General',
    performance: 'Performance',
    wipeAlgorithm: 'Wipe Algorithm',
    requireAuthentication: 'Require Authentication',
    protectApp: 'Protect app with fingerprint or PIN',
    theme: 'Theme',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    autoMode: 'Auto Mode',
    colorCorrection: 'Color Correction',
    language: 'Language',
    about: 'About WipeX',
    version: 'Version 1.0.0',
    privacyFirst: 'Privacy First',
    localOperations: 'All operations are performed locally on your device',

    // Wipe Algorithms
    fastWipe: 'Fast Wipe',
    dodStandard: 'DoD 5220.22-M',
    gutmannMethod: 'Gutmann',
    randomOverwrite: 'Random Overwrite',
    singlePass: 'Single pass overwrite',
    threePassMilitary: '3-pass military standard',
    thirtyFivePass: '35-pass maximum security',
    sevenPassRandom: '7-pass random data',

    // History
    wipeHistory: 'Wipe History',
    noHistory: 'No wipe history available',
    filesWiped: 'Files Wiped',
    completedAt: 'Completed At',
    algorithm: 'Algorithm',
    size: 'Size',

    // Certificates
    wipeCertificates: 'Wipe Certificates',
    noCertificates: 'No certificates available',
    generateCertificate: 'Generate Certificate',
    exportPDF: 'Export PDF',
    exportJSON: 'Export JSON',
    certificateGenerated: 'Certificate Generated',
    dataWipedSecurely: 'Your data has been wiped securely',
    certificationDetails: 'Certification Details',

    // Common
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    export: 'Export',
    success: 'Success',
    error: 'Error',
    warning: 'Warning',
    loading: 'Loading',
    complete: 'Complete',
    progress: 'Progress',
  },
  es: {
    // Navigation
    home: 'Inicio',
    history: 'Historial',
    settings: 'Configuración',
    certificates: 'Certificados',

    // Home Screen
    totalStorage: 'Almacenamiento Total',
    freeSpace: 'Espacio Libre',
    usedSpace: 'Espacio Usado',
    selectFiles: 'Seleccionar Archivos',
    selectFolders: 'Seleccionar Carpetas',
    eraseSpace: 'Borrar Espacio Libre',
    startWipe: 'Iniciar Borrado Seguro',
    storageAnalysis: 'Análisis de Almacenamiento',
    secureWipe: 'WipeX',
    militaryGrade: 'Eliminación segura de archivos de grado militar',
    dataProtection: 'Protección completa de datos',

    // Settings
    security: 'Seguridad',
    appearance: 'Apariencia',
    general: 'General',
    performance: 'Rendimiento',
    wipeAlgorithm: 'Algoritmo de Borrado',
    requireAuthentication: 'Requerir Autenticación',
    protectApp: 'Proteger app con huella o PIN',
    theme: 'Tema',
    darkMode: 'Modo Oscuro',
    lightMode: 'Modo Claro',
    autoMode: 'Modo Automático',
    colorCorrection: 'Corrección de Color',
    language: 'Idioma',
    about: 'Acerca de WipeX',
    version: 'Versión 1.0.0',
    privacyFirst: 'Privacidad Primero',
    localOperations: 'Todas las operaciones se realizan localmente en tu dispositivo',

    // Wipe Algorithms
    fastWipe: 'Borrado Rápido',
    dodStandard: 'DoD 5220.22-M',
    gutmannMethod: 'Gutmann',
    randomOverwrite: 'Sobrescritura Aleatoria',
    singlePass: 'Sobrescritura de una pasada',
    threePassMilitary: 'Estándar militar de 3 pasadas',
    thirtyFivePass: 'Seguridad máxima de 35 pasadas',
    sevenPassRandom: 'Datos aleatorios de 7 pasadas',

    // History
    wipeHistory: 'Historial de Borrado',
    noHistory: 'No hay historial de borrado disponible',
    filesWiped: 'Archivos Borrados',
    completedAt: 'Completado En',
    algorithm: 'Algoritmo',
    size: 'Tamaño',

    // Certificates
    wipeCertificates: 'Certificados de Borrado',
    noCertificates: 'No hay certificados disponibles',
    generateCertificate: 'Generar Certificado',
    exportPDF: 'Exportar PDF',
    exportJSON: 'Exportar JSON',
    certificateGenerated: 'Certificado Generado',
    dataWipedSecurely: 'Tus datos han sido borrados de forma segura',
    certificationDetails: 'Detalles de Certificación',

    // Common
    cancel: 'Cancelar',
    confirm: 'Confirmar',
    delete: 'Eliminar',
    export: 'Exportar',
    success: 'Éxito',
    error: 'Error',
    warning: 'Advertencia',
    loading: 'Cargando',
    complete: 'Completo',
    progress: 'Progreso',
  },
  hi: {
    // Navigation
    home: 'होम',
    history: 'इतिहास',
    settings: 'सेटिंग्स',
    certificates: 'प्रमाणपत्र',

    // Home Screen
    totalStorage: 'कुल स्टोरेज',
    freeSpace: 'खाली जगह',
    usedSpace: 'उपयोग की गई जगह',
    selectFiles: 'फाइलें चुनें',
    selectFolders: 'फोल्डर चुनें',
    eraseSpace: 'खाली जगह मिटाएं',
    startWipe: 'सुरक्षित वाइप शुरू करें',
    storageAnalysis: 'स्टोरेज विश्लेषण',
    secureWipe: 'WipeX',
    militaryGrade: 'मिलिट्री-ग्रेड सुरक्षित फाइल डिलीशन',
    dataProtection: 'पूर्ण डेटा सुरक्षा',

    // Settings
    security: 'सुरक्षा',
    appearance: 'दिखावट',
    general: 'सामान्य',
    performance: 'प्रदर्शन',
    wipeAlgorithm: 'वाइप एल्गोरिदम',
    requireAuthentication: 'प्रमाणीकरण आवश्यक',
    protectApp: 'फिंगरप्रिंट या पिन से ऐप को सुरक्षित करें',
    theme: 'थीम',
    darkMode: 'डार्क मोड',
    lightMode: 'लाइट मोड',
    autoMode: 'ऑटो मोड',
    colorCorrection: 'रंग सुधार',
    language: 'भाषा',
    about: 'WipeX के बारे में',
    version: 'संस्करण 1.0.0',
    privacyFirst: 'गोपनीयता पहले',
    localOperations: 'सभी ऑपरेशन आपके डिवाइस पर स्थानीय रूप से किए जाते हैं',

    // Wipe Algorithms
    fastWipe: 'फास्ट वाइप',
    dodStandard: 'DoD 5220.22-M',
    gutmannMethod: 'गुटमैन',
    randomOverwrite: 'रैंडम ओवरराइट',
    singlePass: 'सिंगल पास ओवरराइट',
    threePassMilitary: '3-पास मिलिट्री स्टैंडर्ड',
    thirtyFivePass: '35-पास अधिकतम सुरक्षा',
    sevenPassRandom: '7-पास रैंडम डेटा',

    // History
    wipeHistory: 'वाइप इतिहास',
    noHistory: 'कोई वाइप इतिहास उपलब्ध नहीं',
    filesWiped: 'फाइलें वाइप की गईं',
    completedAt: 'पूर्ण हुआ',
    algorithm: 'एल्गोरिदम',
    size: 'आकार',

    // Certificates
    wipeCertificates: 'वाइप प्रमाणपत्र',
    noCertificates: 'कोई प्रमाणपत्र उपलब्ध नहीं',
    generateCertificate: 'प्रमाणपत्र जेनरेट करें',
    exportPDF: 'PDF एक्सपोर्ट करें',
    exportJSON: 'JSON एक्सपोर्ट करें',
    certificateGenerated: 'प्रमाणपत्र जेनरेट हुआ',
    dataWipedSecurely: 'आपका डेटा सुरक्षित रूप से वाइप हो गया है',
    certificationDetails: 'प्रमाणन विवरण',

    // Common
    cancel: 'रद्द करें',
    confirm: 'पुष्टि करें',
    delete: 'हटाएं',
    export: 'एक्सपोर्ट',
    success: 'सफलता',
    error: 'त्रुटि',
    warning: 'चेतावनी',
    loading: 'लोड हो रहा है',
    complete: 'पूर्ण',
    progress: 'प्रगति',
  },
};

export const useTranslations = (language: Language): Translations => {
  return translations[language] || translations.en;
};

export default translations;