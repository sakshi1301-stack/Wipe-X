import createContextHook from "@nkzw/create-context-hook";
import { useState, useEffect, useCallback, useMemo } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSettingsStore } from "./settings-store";

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  authenticate: () => Promise<boolean>;
  logout: () => void;
  checkAuthRequired: () => boolean;
}

export const [AuthProvider, useAuth] = createContextHook((): AuthState => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { requireAuth } = useSettingsStore();

  const checkInitialAuth = useCallback(async () => {
    try {
      const lastAuth = await AsyncStorage.getItem("lastAuth");
      const now = Date.now();
      const authTimeout = 5 * 60 * 1000; // 5 minutes

      if (lastAuth && (now - parseInt(lastAuth)) < authTimeout) {
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.log("Auth check error:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkInitialAuth();
  }, [checkInitialAuth]);

  const authenticate = useCallback(async (): Promise<boolean> => {
    try {
      // In a real app, this would handle biometric/PIN authentication
      // For demo purposes, we'll simulate successful authentication
      setIsAuthenticated(true);
      await AsyncStorage.setItem("lastAuth", Date.now().toString());
      return true;
    } catch (error) {
      console.log("Authentication error:", error);
      return false;
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      setIsAuthenticated(false);
      await AsyncStorage.removeItem("lastAuth");
    } catch (error) {
      console.log("Logout error:", error);
    }
  }, []);

  const checkAuthRequired = useCallback((): boolean => {
    return requireAuth && !isAuthenticated;
  }, [requireAuth, isAuthenticated]);

  return useMemo(() => ({
    isAuthenticated,
    isLoading,
    authenticate,
    logout,
    checkAuthRequired,
  }), [isAuthenticated, isLoading, authenticate, logout, checkAuthRequired]);
});